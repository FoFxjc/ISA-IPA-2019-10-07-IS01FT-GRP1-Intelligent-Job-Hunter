"""
 Created by 七月 on 2018/5/1.
"""
__author__ = '七月'


from app import create_app
from app.models.base import db
from app.models.student import Student
from app.models.teacher import Teacher
from app.models.adjustment import Adjustment
from app.models.scheduler import Scheduler
from app.models.calendar import Calendar
import xlrd
import os
import time
import json
import re
import datetime

class readExcel(object):
    def __init__(self, name):
        curpath = os.path.dirname(__file__)
        self.filename = os.path.join(curpath, name)
        self.excel_handle = xlrd.open_workbook(self.filename)  # 路径不包含中


app = create_app()
with app.app_context():
    # from fakename import gen_one_gender_word
    # from fakecolor import randomcolor
    # from fakecolor import randomAge
    # for i in range(1,25):
    #     with db.auto_commit():
    #         stu = Student()
    #         stu.name = gen_one_gender_word(male=True)
    #         stu.create_time = int(time.time())
    #         stu.password = "123456"
    #         stu.gender = "male"
    #         stu.color = randomcolor()
    #         stu.email = stu.name+"@u.nus.edu"
    #         stu.age = randomAge()
    #         db.session.add(stu)
    # for i in range(1,25):
    #     with db.auto_commit():
    #         stu = Student()
    #         stu.name = gen_one_gender_word(male=False)
    #         stu.create_time = int(time.time())
    #         stu.password = "123456"
    #         stu.gender = "female"
    #         stu.color = randomcolor()
    #         stu.email = stu.name+"@u.nus.edu"
    #         stu.age = randomAge()
    #         db.session.add(stu)
    # with db.auto_commit():
    #     # 创建一个超级管理员
    #     tch = Teacher()
    #     tch.name = "jenny"
    #     tch.create_time = int(time.time())
    #     tch.password = "123456"
    #     tch.gender = "female"
    #     tch.color = "#252358"
    #     tch.email = "jenny@jenny.com"
    #     db.session.add(tch)
    # with db.auto_commit():
    #     # 创建一个超级管理员
    #     tch = Adjustment()
    #     tch.name = "no evening"
    #     tch.key = "NE"
    #     tch.create_time = int(time.time())
    #     db.session.add(tch)

    # with db.auto_commit():
    #     # 创建一个超级管理员
    #     tch = Adjustment()
    #     tch.name = "no weekend"
    #     tch.key = "NW"
    #     tch.create_time = int(time.time())
    #     db.session.add(tch)

    # with db.auto_commit():
    #     # 创建一个超级管理员
    #     cal = Calendar()
    #     cal.stu_id = 2
    #     cal.course_id = 1
    #     cal.start_date = int(time.time())
    #     cal.end_date = int(time.time())
    #     cal.type = 'IESTS'
    #     cal.status = 1
    #     db.session.add(cal)
    
    # with db.auto_commit():
    #     # 创建一个超级管理员
    #     sch = Scheduler()
    #     sch.cal_id = 1
    #     sch.category = 'Listening'
    #     sch.start_date = int(time.mktime(datetime.datetime.now().timetuple()))
    #     sch.end_date = int(time.mktime((datetime.datetime.now() + datetime.timedelta(hours=2)).timetuple()))
    #     sch.detail = 'Listening of IESTS'
    #     sch.status = 1
    #     db.session.add(sch)
