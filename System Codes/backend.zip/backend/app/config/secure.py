# -*- coding: utf-8 -*-


#Dev
SQLALCHEMY_DATABASE_URI = \
   'mysql+cymysql://root:123456@localhost:3306/ipatp?charset=utf8'


# Docker    
#SQLALCHEMY_DATABASE_URI = \
#    'mysql+cymysql://root:XJCxjcshsf@mysql:3306/mrtp?charset=utf8'
    
SECRET_KEY = r'\x88D\xf09\x6\xa0A\x7\xc5V\xbe\x8b\xef\xd7\xd8\xd3\xe6\x98*4'
