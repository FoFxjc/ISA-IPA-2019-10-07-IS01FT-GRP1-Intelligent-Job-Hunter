import os
import ast

def buildHtml(jobs,openid):
	
	wholeMessage = ""
	message = """
	<!DOCTYPE html>
	<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="">

		<title>Narrow Jumbotron Template for Bootstrap</title>

		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
    <script src="https://cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
		
		<style type="text/css">
            /* Space out content a bit */
            body {
            padding-top: 20px;
            padding-bottom: 20px;
            }

            /* Everything but the jumbotron gets side spacing for mobile first views */
            .header,
            .marketing,
            .footer {
            padding-right: 15px;
            padding-left: 15px;
            }

            /* Custom page header */
            .header {
            padding-bottom: 20px;
            border-bottom: 1px solid #e5e5e5;
            }
            /* Make the masthead heading the same height as the navigation */
            .header h3 {
            margin-top: 0;
            margin-bottom: 0;
            line-height: 40px;
            }
            a{
                color: #FFF;
                border-radius: 5px;
                padding: 10px 24px;
                font-size: 21px;
            }
            .btn_select{
                
                background-color: #aaa;

            }

            .btn_submit{
                background-color: rgb(104, 104, 141);

            }
            /* Custom page footer */
            .footer {
            padding-top: 19px;
            color: #777;
            border-top: 1px solid #e5e5e5;
            }

            /* Customize container */
            @media (min-width: 768px) {
                .container {
                    max-width: 730px;
                }
            }
            .container-narrow > hr {
            margin: 30px 0;
            }

            /* Main marketing message and sign up button */
            .jumbotron {
            text-align: center;
            border-bottom: 1px solid #e5e5e5;
            }
            .jumbotron .btn {
            padding: 14px 24px;
            font-size: 21px;
            }

            /* Supporting marketing content */
            .marketing {
            margin: 40px 0;
            }
            .marketing p + h4 {
            margin-top: 28px;
            }

            /* Responsive: Portrait tablets and up */
            @media screen and (min-width: 768px) {
                /* Remove the padding we set earlier */
                .header,
                .marketing,
                .footer {
                    padding-right: 0;
                    padding-left: 0;
                }
                /* Space out the masthead */
                .header {
                    margin-bottom: 30px;
                }
                /* Remove the bottom border on the jumbotron for visual effect */
                .jumbotron {
                    border-bottom: 0;
                }
            }

		</style>
		<script>
	"""
	wholeMessage = wholeMessage + message

	#加入数组

	listMessage = ""
	message = """
	var numList = ["""
	listMessage = listMessage + message
	
	for jobDescripe in jobs:
		html_temp = '%s,' % jobDescripe.id
		listMessage = listMessage + html_temp

	wholeMessage = wholeMessage + listMessage[:-1]

	message = """];
	"""
	wholeMessage = wholeMessage + message


	message = """
		
			$(document).ready(function(){
					$(".btn_select").click(function(){
					if ($(this).text() == "Select"){
						$(this).text("Unselect");
					}
					else{
						$(this).text("Select");
					}
				});
				$("#submit_button").click(function(){
					if($(this).text() != "Already Submit"){
						
						var i = 1;
						var str_temp = "";
					
						while(i){
							var id_temp = "#btn" + numList[i-1];
							if($(id_temp).length>0)
							{
								if ($(id_temp).text() == "Unselect"){
									str_temp = str_temp + id_temp + ","
								}
								i = i+1;
							}
							else
							{
								break;
							}
							
						}
						if(str_temp.length<2){
							alert("Please make a choice.")
						}
						else{
							var data = {
							'result': str_temp
						}
						var test = window.location.href;
						var start = test.indexOf("JPhtml");
						var atest = test.slice(0,start+6)+'/select'+test.slice(start+6)
						$(this).text("Already Submit");
						$.ajax({
							type: 'GET',
							url: atest,
							data: data,                  
							dataType: 'json',           
							success: function(data){    
								location.reload([true])   
							}
						});
						}
					}
				});

			});
		</script>
	</head>
	<body>
		<nav class="navbar navbar-fixed-top navbar-inverse">
			<div class="container">
				<div class="navbar-header" style="border-bottom:1px solid black;width:100%;text-align:center;">
				<p class="navbar-brand" style="top:0;z-index:99;">Job Opportunites</p>
				</div>

			</div>
			</nav>
		<div class="container" style="margin-top:50px;">
	"""
	wholeMessage = wholeMessage + message
	#begin to add html
	for jobDescripe in jobs:
		flag = True
		try:
			pass
		except:
			flag = False
			pass
		if flag :
			description = ''.join([''.join(v) for k,v in ast.literal_eval(jobDescripe.description).items()])[:400]+"..."
			requirement = ''.join([''.join(v) for k,v in ast.literal_eval(jobDescripe.requirement).items()])[:400]+"..."
			
			_job = ""
			if description == "...":
				_job = requirement
			else:
				_job = description
		else:
			_job = jobDescripe.description
		
		htmlMessgae = """
		<div class="jumbotron">
			<h2>%s</h2>
		""" % (jobDescripe.title)


		##########################################
		if jobDescripe.company_name != None:
			html_temp = """
			<p class="lead">%s</p>

			""" % jobDescripe.company_name
			htmlMessgae = htmlMessgae + html_temp
		

		html_temp = """
		</div>

		<div class="row marketing">
			<div class="col-lg-6">
		"""
		htmlMessgae = htmlMessgae + html_temp

		html_temp = """
			<h4>JOB DESCRIPTION</h4>
			<p>%s</p>

		""" % _job
		htmlMessgae = htmlMessgae + html_temp

		##########################################
		if jobDescripe.salary != None:
			html_temp = """
				<h4>SALARY</h4>
				<p>%s</p>
				
			""" % jobDescripe.salary
			htmlMessgae = htmlMessgae + html_temp

		##########################################
		if jobDescripe.location != None:
			html_temp = """
				<h4>LOCATION</h4>
				<p>%s</p>
				
			""" % jobDescripe.location
			htmlMessgae = htmlMessgae + html_temp

		html_temp = """
			</div>

            <p><a class="btn_select" id="btn%s" role="button">Select</a></p>
		</div>
		""" % jobDescripe.id
		htmlMessgae = htmlMessgae + html_temp

		wholeMessage = wholeMessage + htmlMessgae

	# 写入HTML界面中
	message = """
            <p><a class="btn_submit" id="submit_button" role="button">Submit</a></p>
			<footer class="footer">
			<p>&copy; Job Interview Hunter</p>
		</footer>
		</div>
    
	</body>
	</html>
	"""
	wholeMessage = wholeMessage + message

	return wholeMessage


def buildEmptyHtml():
	wholeMessage = """
		<!DOCTYPE html>
		<html lang="en">
		<head>
			<meta charset="utf-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
			<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
			<script src="https://cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script>
			<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
			<style type="text/css">
					a,
					a:focus,
					a:hover {
					color: #fff;
					}
					html,
					body {
					height: 100%;
					background-color: #333;
					}
					body {
					color: #fff;
					text-align: center;
					text-shadow: 0 1px 3px rgba(0,0,0,.5);
					}
					/* Extra markup and styles for table-esque vertical and horizontal centering */
					.site-wrapper {
					display: table;
					width: 100%;
					height: 100%; /* For at least Firefox */
					min-height: 100%;
					-webkit-box-shadow: inset 0 0 100px rgba(0,0,0,.5);
							box-shadow: inset 0 0 100px rgba(0,0,0,.5);
					}
					.site-wrapper-inner {
					display: table-cell;
					vertical-align: top;
					}
					.cover-container {
					margin-right: auto;
					margin-left: auto;
					}
					/* Padding for spacing */
					.inner {
					padding: 30px;
					}
					.cover {
					padding: 0 20px;
					}
					@media (min-width: 768px) {
					.site-wrapper-inner {
						vertical-align: middle;
					}
					.cover-container {
						width: 100%; 
					}
					}
					@media (min-width: 992px) {
					.cover-container {
						width: 700px;
					}
					}
			</style>
		</head>
		<body>
			<div class="site-wrapper">
			<div class="site-wrapper-inner">
				<div class="cover-container">
				<div class="inner cover" style="margin-top:100px;">
					<h1 class="cover-heading">You Have Already Submitted.</h1>
				</div>
				<footer class="footer">
					<p>&copy; Job Interview Hunter</p>
				</footer>
				</div>
			</div>
			</div>
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		</body>
		</html>
	"""
	return wholeMessage

def buildOverDueHtml():
	wholeMessage = """
		<!DOCTYPE html>
		<html lang="en">
		<head>
			<meta charset="utf-8">
			<meta http-equiv="X-UA-Compatible" content="IE=edge">
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
			<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" integrity="sha384-HSMxcRTRxnN+Bdg0JdbxYKrThecOKuH5zCYotlSAcp1+c8xmyTe9GYg1l9a69psu" crossorigin="anonymous">
			<script src="https://cdn.bootcss.com/jquery/1.11.3/jquery.min.js"></script>
			<script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js" integrity="sha384-aJ21OjlMXNL5UyIl/XNwTMqvzeRMZH2w8c5cRVpzpU8Y5bApTppSuUkhZXN0VxHd" crossorigin="anonymous"></script>
			<style type="text/css">
					a,
					a:focus,
					a:hover {
					color: #fff;
					}
					html,
					body {
					height: 100%;
					background-color: #333;
					}
					body {
					color: #fff;
					text-align: center;
					text-shadow: 0 1px 3px rgba(0,0,0,.5);
					}
					/* Extra markup and styles for table-esque vertical and horizontal centering */
					.site-wrapper {
					display: table;
					width: 100%;
					height: 100%; /* For at least Firefox */
					min-height: 100%;
					-webkit-box-shadow: inset 0 0 100px rgba(0,0,0,.5);
							box-shadow: inset 0 0 100px rgba(0,0,0,.5);
					}
					.site-wrapper-inner {
					display: table-cell;
					vertical-align: top;
					}
					.cover-container {
					margin-right: auto;
					margin-left: auto;
					}
					/* Padding for spacing */
					.inner {
					padding: 30px;
					}
					.cover {
					padding: 0 20px;
					}
					@media (min-width: 768px) {
					.site-wrapper-inner {
						vertical-align: middle;
					}
					.cover-container {
						width: 100%; 
					}
					}
					@media (min-width: 992px) {
					.cover-container {
						width: 700px;
					}
					}
			</style>
		</head>
		<body>
			<div class="site-wrapper">
			<div class="site-wrapper-inner">
				<div class="cover-container">
				<div class="inner cover" style="margin-top:100px;">
					<h1 class="cover-heading">Webpage has expired.</h1>
				</div>
				<footer class="footer">
					<p>&copy; Job Interview Hunter</p>
				</footer>
				</div>
			</div>
			</div>
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		</body>
		</html>
	"""
	return wholeMessage