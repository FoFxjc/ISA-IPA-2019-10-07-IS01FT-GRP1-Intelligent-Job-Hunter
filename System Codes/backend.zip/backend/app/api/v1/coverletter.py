"""
 Create by jiachenx on 2019/3/11
"""
import copy
import hashlib
import os
import shutil

from flask import Response, g, jsonify, request, send_file
from sqlalchemy import or_

from app.app import APP_ROOT
from app.libs.error_code import ParameterExceptionWarning, Success
from app.libs.redprint import Redprint
from app.libs.token_auth import auth
from app.libs.utils import generate_detail
from app.models import job, resume
from app.models.base import db
from app.models.user import User
from app.models import coverletter
from app.nlp.IPA import ApplicantDB, Job, JobDB, Resume
from app.validators.forms import getresumePDFForm, uploadresumeDataForm,getCoverLetterDataForm,getJobPDFForm,getCoverLetterPDFForm,uploadCoverLetterDataForm,submitJobCVSelectionForm
from app.viewmodels.resume import ResumeViewModel
from app.viewmodels.coverletter import CoverLetterViewModel,CoverLetterCollection
import ast
import time
import subprocess
from app.libs.utils import replace_char_for_latex

__author__ = 'jiachenx'

api = Redprint('coverletter')

nlp_execute_path = os.path.join(APP_ROOT, "nlp/")

@api.route('/getJobPDF', methods=['GET'])
def getJobPDF():
  form = getJobPDFForm().validate_for_api()
  job_id = form.job_id.data
  job_sql = job.Job.query.filter_by(id=job_id).first_or_404()
  return send_file(job_sql.file_location)

@api.route('/getCoverLetterPDF', methods=['GET'])
def getCoverLetterPDF():
  form = getCoverLetterPDFForm().validate_for_api()
  cv_id = form.cv_id.data
  cv_sql = coverletter.CoverLetter.query.filter_by(id=cv_id).first_or_404()
  return send_file(cv_sql.cover_file_location_origin)

@api.route('/getCoverLetterData', methods=['POST'])
@auth.login_required
def getCoverLetterData():
  form = getCoverLetterDataForm().validate_for_api()

  jobs = job.Job.query.filter_by(u_id=form.uid.data,status=2).all()

  jobs_id = [job.id for job in jobs]

  coverletters = coverletter.CoverLetter.query.filter(coverletter.CoverLetter.j_id.in_(jobs_id)).all()

  coverLetterCollection = CoverLetterCollection()
  coverLetterCollection.fill(coverletters)

  data = {
    'jobs':jobs_id,
    'coverletters':coverLetterCollection.data
  }

  return jsonify(data)

@api.route('/uploadCoverLetterData', methods=['POST'])
@auth.login_required
def uploadCoverLetterData():
  uid = g.user.uid
  form = uploadCoverLetterDataForm().validate_for_api()

  coverletter_sql = coverletter.CoverLetter.query.filter_by(id=form.id.data).first()
  coverletter_data_sql = ast.literal_eval(coverletter_sql.cover_letter_data)


  ischange = True
  if coverletter_data_sql["sender_name"] != form.sender_name.data:
    ischange = True
  if coverletter_data_sql["sender_phone"] != form.sender_phone.data:
    ischange = True
  if coverletter_data_sql["sender_email"] != form.sender_email.data:
    ischange = True
  if coverletter_data_sql["recipiant_title"] != form.recipiant_title.data:
    ischange = True
  if coverletter_data_sql["first_paragraph"] != form.first_paragraph.data:
    ischange = True
  if coverletter_data_sql["secend_paragraph"] != form.secend_paragraph.data:
    ischange = True
  if coverletter_data_sql["third_paragraph"] != form.third_paragraph.data:
    ischange = True
  if coverletter_data_sql["fourth_paragraph"] != form.fourth_paragraph.data:
    ischange = True
  
  if not ischange:
    return Success(msg="The update data is the same as the original one, Skip regenerating")
  else:
    temp_coverletter = os.path.join(APP_ROOT, "templates/templates.tex")

    today = time.strftime("%Y%m%d", time.localtime()) 

    print(today)
    user_coverletter_path = os.path.join(APP_ROOT, "data/"+str(uid)+"/coverletter/"+str(today))
    print(user_coverletter_path)
    shutil.copy(temp_coverletter,
              os.path.join(user_coverletter_path, "templates.tex"))
    
    print(user_coverletter_path)

    sender_name = form.sender_name.data
    sender_phone = form.sender_phone.data
    sender_email = form.sender_email.data
    recipiant_title = form.recipiant_title.data
    date = time.strftime("%B %d %Y", time.localtime()) 
    first_paragraph = form.first_paragraph.data
    secend_paragraph = form.secend_paragraph.data
    third_paragraph = form.third_paragraph.data
    fourth_paragraph = form.fourth_paragraph.data

   

    template = open(os.path.join(user_coverletter_path, "templates.tex"), "r")
    content = template.read()
    content = content.replace('%[name]',sender_name)
    content = content.replace('%[phone]',sender_phone)
    content = content.replace('%[email]',sender_email)
    content = content.replace('%[date]',date)
    content = content.replace('%[recipiant_title]',recipiant_title)
    content = content.replace('%[first_paragraph]',replace_char_for_latex(first_paragraph,['%','#','$']))
    content = content.replace('%[secend_paragraph]',replace_char_for_latex(secend_paragraph,['%','#','$']))
    content = content.replace('%[third_paragraph]', replace_char_for_latex(third_paragraph,['%','#','$']))
    content = content.replace('%[fourth_paragraph]',replace_char_for_latex(fourth_paragraph,['%','#','$']))
    print(content)

    _cover_letter_data = {
      'sender_name' :sender_name,
      'sender_phone' :sender_phone,
      'sender_email' :sender_email,
      'recipiant_title' :recipiant_title,
      'date' :date,
      'first_paragraph' :first_paragraph,
      'secend_paragraph' :secend_paragraph,
      'third_paragraph' :third_paragraph,
      'fourth_paragraph' :fourth_paragraph,
    }
    with open(os.path.join(user_coverletter_path, "templates_"+str(coverletter_sql.j_id)+".tex"),'w',encoding='utf-8') as f:
        f.write(content)
    _r = subprocess.check_output(['powershell.exe',' pdflatex','-output-directory="'+user_coverletter_path+'"',
                               '-job-name="coverletter_'+str(coverletter_sql.j_id)+'"','"'+os.path.join(user_coverletter_path, 'templates_'+str(coverletter_sql.j_id)+'.tex')+'"'],shell=False)
    os.remove(os.path.join(user_coverletter_path, "coverletter_"+str(coverletter_sql.j_id)+".aux"))
    os.remove(os.path.join(user_coverletter_path, "coverletter_"+str(coverletter_sql.j_id)+".log"))
    os.remove(os.path.join(user_coverletter_path, "coverletter_"+str(coverletter_sql.j_id)+".out"))

    coverletter_sql = coverletter.CoverLetter.query.filter_by(id=form.id.data).first()
    coverletter_sql.cover_letter_data = str(_cover_letter_data)
    coverletter_sql.cover_file_location_origin = os.path.join(user_coverletter_path,'coverletter_'+str(coverletter_sql.j_id)+'.pdf')
    db.session.commit()

  return Success(msg="Regenerate Successfully")


@api.route('/submit',methods=['POST'])
@auth.login_required
def submit():
  uid = g.user.uid
  form = submitJobCVSelectionForm().validate_for_api()
  user = User.query.filter_by(id=uid).first_or_404()
  if(user.check_password(form.password.data)):
    from app.api.v1.wechat import wechat_sender
    from app.models import job
    jobs = job.Job.query.filter(job.Job.id.in_(form.jobs.data)).all()
    for job in jobs:
      job.status = 3
      db.session.commit()
    user.daily_select = 2
    db.session.commit()
    wechat_sender("You finish the cover letter,Should we send the email to the companies for you?",user.openid)
    return Success()
  else:
    return ParameterExceptionWarning(msg="Wrong Password")