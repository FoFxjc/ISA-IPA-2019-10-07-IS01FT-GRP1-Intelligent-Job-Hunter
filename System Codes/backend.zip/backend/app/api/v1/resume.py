"""
 Create by jiachenx on 2019/3/11
"""
import copy
import hashlib
import os
import shutil

from flask import Response, g, jsonify, request, send_file
from sqlalchemy import or_

from app.app import APP_ROOT
from app.libs.error_code import ParameterExceptionWarning, Success
from app.libs.redprint import Redprint
from app.libs.token_auth import auth
from app.libs.utils import generate_detail
from app.models import job, resume,coverletter
from app.models.base import db
from app.models.user import User
from app.nlp.IPA import ApplicantDB, Job, JobDB, Resume
from app.nlp.CoverLetter import CoverLetter
from app.validators.forms import getresumePDFForm, uploadresumeDataForm
from app.viewmodels.resume import ResumeViewModel
import time
import subprocess
import re

__author__ = 'jiachenx'

api = Redprint('resume')

nlp_execute_path = os.path.join(APP_ROOT, "nlp/")

@api.route('/getresumePDF', methods=['GET'])
def generatePDF():
  form = getresumePDFForm().validate_for_api()
  uid = form.uid.data
  resume_sql = resume.Resume.query.filter_by(u_id=uid).first()
  return send_file(resume_sql.resume_location)

@api.route('/getresumeData', methods=['GET'])
@auth.login_required
def getresumeData():
  uid = g.user.uid
  resume_sql = resume.Resume.query.filter_by(u_id=uid).first()
  resume_vm = ResumeViewModel(resume_sql)
  return jsonify(resume_vm)

@api.route('/uploadresumeData', methods=['POST'])
@auth.login_required
def uploadresumeData():
  uid = g.user.uid
  form = uploadresumeDataForm().validate_for_api()
  user = User.query.filter_by(id=uid).first_or_404()
  if(user.check_password(form.password.data)):
    resume_sql = resume.Resume.query.filter_by(id=form.id.data).first_or_404()
    compare_temp_data = copy.copy(resume_sql)
    resume_sql.name = form.name.data
    resume_sql.phone = form.phone.data
    resume_sql.email = form.email.data
    resume_sql.resume_type = str(form.resume_type.data)
    resume_sql.education_experience = str(form.education_experience.data)
    resume_sql.project_experience = str(form.project_experience.data)
    compare_result = generate_detail(resume_sql, compare_temp_data)
    if any(compare_result):
      db.session.commit()
      del compare_result
      del compare_temp_data
      return Success(msg="Save Successfully")
    else:
      del compare_result
      del compare_temp_data
      return Success(msg="The update data is the same as the original one, Save Nothing")
  else:
    return ParameterExceptionWarning(msg="Wrong Password")

@api.route('/upload', methods=['POST'])
@auth.login_required
def upload():
  uid = g.user.uid
  if 'file' not in request.files:
    return redirect(request.url)
  file = request.files['file']
  filename = file.filename
  filename = filename.replace(' ', '')

  user = User.query.filter_by(id=uid).first_or_404()
  user_resume_path = os.path.join(APP_ROOT, "data/"+str(user.id)+"/"+"resume/")
  
  # resume file save
  isExists=os.path.exists(user_resume_path)
  if not isExists:
    os.makedirs(user_resume_path) 
    
  file.save(os.path.join(user_resume_path, filename))
  shutil.copy(os.path.join(user_resume_path, filename),
              os.path.join(nlp_execute_path, "exe/"+filename))

  for item in os.walk(os.path.join(nlp_execute_path, "exe/")):
    files=item[2]
    for file in files:
      if(file.endswith('.txt') or file.endswith('.html')):
        os.remove(os.path.join(nlp_execute_path, "exe/")+file)

  
  # database ready
  applicationDB = ApplicantDB(os.path.join(nlp_execute_path, "workex/"))
  _resume = Resume(os.path.join(nlp_execute_path, "exe/"+filename))

  # extraction
  _extracted = _resume.extract(applicationDB.documents)


  print(_extracted)
  resume_type = _extracted['resume_type']

  project_experience = _extracted['projects']

  name = _extracted['name']

  email = _extracted['email']

  phone = _extracted['phone']

  project_infos = []
  print(project_experience)

  for k,v in project_experience.items():
    _info = {}
    _info['type'] = k
    _info['company'] = ''
    _info['date'] = v[0]
    _info['summary'] = ''.join(v[1][0:])
    project_infos.append(_info)
  print(project_infos)
  education_experience = _extracted['education']
  education_infos = []
  for education_info in education_experience:
    _info = {}
    _info['date'] = str(education_info[0]) + "-" + str(education_info[1])
    _info['school'] = education_info[2]
    education_infos.append(_info)
  print(education_infos)
  with db.auto_commit():
    resume_sql = resume.Resume()
    resume_sql.u_id = user.id
    resume_sql.name = name
    resume_sql.phone = phone
    if isinstance(email,list):
      resume_sql.email = email[0]
    else:
      resume_sql.email = email
    resume_sql.resume_type = str(resume_type)
    resume_sql.education_experience = str(education_infos)
    resume_sql.project_experience = str(project_infos)
    resume_sql.resume_location = os.path.join(user_resume_path, filename)
    resume_sql.status = 0
    db.session.add(resume_sql)

  return Success()
  # return send_file(os.path.join(APP_ROOT, 'generater/test.pdf'))



# @api.route('/jobtest', methods=['GET'])
# def jobtest():
#   user_resume_path = os.path.join(APP_ROOT, "data/9/jobpostion/20191019/IBMInternship.pdf")
#   filename = "IBMInternship.pdf"
#   shutil.copy(user_resume_path,
#               os.path.join(nlp_execute_path, "exe/"+filename))
  
#   # database ready
#   applicationDB = ApplicantDB(os.path.join(nlp_execute_path, "workex/"))
#   _job = Job(os.path.join(nlp_execute_path, "exe/"+filename))

#   roleDB=JobDB(os.path.join(nlp_execute_path, "JobResponsibility"))
#   reqDB=JobDB(os.path.join(nlp_execute_path, "JobRequirement"))

#   _job.convert()
#   jobtype,role,req = _job.extract(roleDB.documents,reqDB.documents)
  
#   with db.auto_commit():
#     job_sql = job.Job()
#     job_sql.u_id = 9
#     job_sql.title = filename
#     job_sql.requirement = str(role)
#     job_sql.description = str(req)
#     job_sql.file_location = os.path.join(nlp_execute_path, "exe/"+filename)
#     job_sql.status = 0
#     job_sql.type = jobtype
#     db.session.add(job_sql)
#   return Success()


# @api.route('/cvtest', methods=['GET'])
# def cvtest():
#   users = User.query.filter_by(id=9).all()
#   for user in users:
#     resume_sql = resume.Resume.query.filter_by(u_id=user.id).first()
#     jobs = job.Job.query.filter_by(u_id=user.id).all()
#     print(len(jobs))

#     cv_temp_path = os.path.join(APP_ROOT, "nlp/coverletter_temp/")

#     with open(os.path.join(cv_temp_path, "first_para.txt"),'r',encoding='utf-8') as f:
#       para1=f.read()
#     with open(os.path.join(cv_temp_path, "second_para.txt"),'r',encoding='utf-8') as f:
#       para2=f.read()
#     with open(os.path.join(cv_temp_path, "third_para.txt"),'r',encoding='utf-8') as f:
#       para3=f.read()
#     with open(os.path.join(cv_temp_path, "fourth_para.txt"),'r',encoding='utf-8') as f:
#       para4=f.read()
    
#     coverletter_generator = CoverLetter(para1,para2,para3,para4)

#     _result =  coverletter_generator.create_letter(resume=resume_sql,jobs=jobs)

#     print(_result)
#     for item in _result:
#       # generate the coverletter
#       sender_name = resume_sql.name
#       sender_phone = resume_sql.phone
#       sender_email = resume_sql.email
#       recipiant_title = "Dear Sir or Madam"
#       date = time.strftime("%B %d %Y", time.localtime()) 
#       first_paragraph = item["jobs"][0]['letter'][0]
#       secend_paragraph = item["jobs"][0]['letter'][1]
#       third_paragraph = item["jobs"][0]['letter'][2]
#       fourth_paragraph = item["jobs"][0]['letter'][3]

#       template = open(os.path.join(APP_ROOT, "templates/templates.tex"), "r")
#       content = template.read()
#       content = content.replace('%[name]',sender_name)
#       content = content.replace('%[phone]',sender_phone)
#       content = content.replace('%[email]',sender_email)
#       content = content.replace('%[date]',date)
#       content = content.replace('%[recipiant_title]',recipiant_title)
#       content = content.replace('%[first_paragraph]',first_paragraph)
#       content = content.replace('%[secend_paragraph]',secend_paragraph)
#       content = content.replace('%[third_paragraph]', third_paragraph)
#       content = content.replace('%[fourth_paragraph]',fourth_paragraph)
#       print(content)

#       _cover_letter_data = {
#         'sender_name' :sender_name,
#         'sender_phone' :sender_phone,
#         'sender_email' :sender_email,
#         'recipiant_title' :recipiant_title,
#         'date' :date,
#         'first_paragraph' :first_paragraph,
#         'secend_paragraph' :secend_paragraph,
#         'third_paragraph' :third_paragraph,
#         'fourth_paragraph' :fourth_paragraph,
#       }

#       date = time.strftime("%Y%m%d", time.localtime())

#       cover_letter_path = os.path.join(APP_ROOT, "data/"+str(user.id)+"/coverletter/"+str(date))

#       isExists=os.path.exists(cover_letter_path)
#       if not isExists:
#         os.makedirs(cover_letter_path) 
      
#       with open(os.path.join(cover_letter_path, "templates_"+str(item["jobs"][0]['jobid'])+".tex"),'w',encoding='utf-8') as f:
#         f.write(content)
#       # pdflatex  -output-directory="./" -job-name="coverletter"  .\templates.tex.bk
#       _r = subprocess.check_output(['powershell.exe',' pdflatex','-output-directory="'+cover_letter_path+'"',
#                                '-job-name="coverletter_'+str(item["jobs"][0]['jobid'])+'"','"'+os.path.join(cover_letter_path, 'templates_'+str(item["jobs"][0]['jobid'])+'.tex')+'"'],shell=False)
#       os.remove(os.path.join(cover_letter_path, "coverletter_"+str(item["jobs"][0]['jobid'])+".aux"))
#       os.remove(os.path.join(cover_letter_path, "coverletter_"+str(item["jobs"][0]['jobid'])+".log"))
#       os.remove(os.path.join(cover_letter_path, "coverletter_"+str(item["jobs"][0]['jobid'])+".out"))
#       with db.auto_commit():
#         _cover_letter = coverletter.CoverLetter()
#         _cover_letter.u_id = user.id
#         _cover_letter.j_id = item["jobs"][0]['jobid']
#         _cover_letter.cover_letter_data = str(_cover_letter_data)
#         _cover_letter.cover_file_location_origin = os.path.join(cover_letter_path,'coverletter_'+str(item["jobs"][0]['jobid'])+'.pdf')
#         _cover_letter.status = 0
#         db.session.add(_cover_letter)
#     return Success()
