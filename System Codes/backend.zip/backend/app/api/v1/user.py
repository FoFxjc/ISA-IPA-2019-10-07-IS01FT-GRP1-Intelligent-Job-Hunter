"""
 Create by jiachenx on 2019/3/11
"""
import copy

from flask import g, jsonify,current_app
from sqlalchemy import or_

from app.libs.enums import roles
from app.libs.error_code import (AuthFailed, DeleteSuccess,
                                 ParameterExceptionWarning, Success)
from app.libs.redprint import Redprint
from app.libs.token_auth import auth
from app.libs.utils import generate_detail
from app.models.base import db
from app.validators.forms import (AddUserForm, RegisterForm,
                                  UpdatePasswordForm, UpdateUserForm,
                                  UserInfoSearchForm,UploadMonitorEmail)
from app.viewmodels.user import UserViewModel
from app.models.user import User
from itsdangerous import BadSignature, SignatureExpired
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer

__author__ = 'jiachenx'

api = Redprint('user')


@api.route('/update', methods=['POST'])
@auth.login_required
def update_user():
  form = UpdateUserForm().validate_for_api()
  user = User.query.filter_by(id=form.id.data).first_or_404()
  compare_temp_data = copy.copy(user)
  user.name = form.name.data
  user.email = form.email.data
  user.age = form.age.data
  user.gender = form.gender.data
  compare_result = generate_detail(user, compare_temp_data)
  if any(compare_result):
    db.session.commit()
    del compare_result
    del compare_temp_data
  else:
    del compare_result
    del compare_temp_data
    return Success(msg="The update data is the same as the original one, Save Nothing")
  return Success(msg="Save Successfully")


@api.route('/info', methods=['GET'])
@auth.login_required
def get_user():
  # g 变量线程隔离
  uid = g.user.uid
  scope = g.user.scope
  user = User.query.filter_by(id=uid).first_or_404()
  uservm = UserViewModel(user)
  return jsonify(uservm)


@api.route('/updatepassword', methods=['POST'])
@auth.login_required
def update_password():
  # g 变量线程隔离
  uid = g.user.uid
  scope = g.user.scope
  form = UpdatePasswordForm().validate_for_api()
  user = User.query.filter_by(id=uid).first_or_404()
  if(user.check_password(form.oldpwd.data)):
    compare_temp_data = copy.copy(user)
    user.password = form.newpwd.data
    db.session.commit()
    return Success(msg="Change Password Successfully")
  else:
    return ParameterExceptionWarning(msg="Wrong Old Password")


@api.route('/register', methods=['POST'])
def register():
  form = RegisterForm().validate_for_api()
  if(User.isDuplicatedName(form.name.data)):
    return ParameterExceptionWarning(msg="Duplicated Name, Please try another name")
  user = User.query.filter_by(openid=form.openid.data).first_or_404()
  user.name = form.name.data
  user.email = form.email.data
  user.age = form.age.data
  user.password = form.password.data
  user.gender = form.gender.data
  db.session.commit()
  user = User.query.filter_by(openid=form.openid.data).first_or_404()
  expiration = current_app.config['TOKEN_EXPIRATION']
  token = generate_auth_token(user.id,"user",expiration)
  t = {
        'status':0,
        'data': {
            'token':token.decode('ascii')
        }
  }
  return Success(msg=t)

@api.route('/uploadmonitorEmail', methods=['POST'])
@auth.login_required
def upload_monitoremail():
  # g 变量线程隔离
  uid = g.user.uid
  scope = g.user.scope
  form = UploadMonitorEmail().validate_for_api()
  user = User.query.filter_by(id=uid).first_or_404()
  if(user.check_password(form.password.data)):
    user.monitor_email_account = form.monitor_email_account.data
    user.monitor_email_password = form.monitor_email_password.data
    db.session.commit()
    return Success(msg="Upload Monitored Email Successfully")
  else:
    return ParameterExceptionWarning(msg="Wrong Password")


def generate_auth_token(uid, scope=None,
                        expiration=7200):
    print(expiration)
    s = Serializer(current_app.config['SECRET_KEY'],
                   expires_in=expiration)
    return s.dumps({
        'uid': uid,
        'scope':scope
    })
