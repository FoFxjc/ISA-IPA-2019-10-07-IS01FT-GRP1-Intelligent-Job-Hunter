"""
 Create by jiachenx on 2019/3/11
"""
from flask import jsonify,request,current_app
from sqlalchemy import or_
import copy
from app.libs.error_code import Success
from app.libs.redprint import Redprint
from app.libs.token_auth import auth
from app.models.base import db
from app.libs.flask_wechatpy import Wechat, wechat_required, oauth
from wechatpy.replies import TextReply
from wechatpy.replies import create_reply
from wechatpy.events import SubscribeEvent,SubscribeScanEvent,ScanEvent,UnsubscribeEvent,ClickEvent
import os
import time
import datetime
import requests, json
from wechatpy import WeChatClient
from flask import send_file,send_from_directory,url_for
from app.models.user import User
from app.models.job import Job
from app.validators.forms import GenerateWechatHtmlForm
from app.api.v1.wechatHtml import buildHtml,buildEmptyHtml,buildOverDueHtml
from app.rpa.outlook_send import sendmail
from app.models.resume import Resume
from app.models.coverletter import CoverLetter
from nltk.tokenize import word_tokenize 
__author__ = 'jiachenx'
htmlOpenid = ""
api = Redprint('wechat')


@api.route('/', methods=['GET', 'POST'])
@wechat_required
def wechat_handler():
	emailFlag = False
	
	yesList = ["yes",  "ok", "absolute","send","sure"]
	noList = ["no", "not", "don't", "cannot", "donot", "shouldn't","not","shouldnot"]
	
	msg = request.wechat_msg
	print(msg)
	if msg.type == 'event':
		if isinstance(msg,ClickEvent):
		  return handleMenuEvent(msg)
		if isinstance(msg,SubscribeScanEvent):
		  return handleSubscribeScanEvent(msg)
		if isinstance(msg,ScanEvent):
		  return handleScanEvent(msg)
		if isinstance(msg,UnsubscribeEvent):
		  return handleUnsubscribeEvent(msg)
	if msg.type == 'text':
		#emailFlag should be change when send message
		users = User.query.filter_by(openid=msg.source).first()
		print(msg.source)
		if not users:
			reply = TextReply(content="You have not logged in our system.", message=msg)
			return reply
		if users.daily_select == 2:
			emailFlag = True
		emailFlag = True
		if emailFlag:
			#use nltk to cut message
			sentenceWord = word_tokenize(msg.content.lower())
			if(len([word for word in sentenceWord if word in yesList])>0):
				reply = TextReply(content="Sending email, please wait.", message=msg)
				jobs =Job.query.filter_by(u_id=users.id,status=3).all()
				resume = Resume.query.filter_by(u_id=users.id).first()
				for job in jobs:
					coverletter = CoverLetter.query.filter_by(u_id=users.id,j_id=job.id).first()
					sendmail("e0402076@u.nus.edu",resume.resume_location,coverletter.cover_file_location_origin,resume.email,resume.name,job.title)
				emailFlag = False
				#change the user.daily_select
				users.daily_select = 1
				db.session.commit()
			#if cant match yes try no
			if emailFlag:
				if(len([word for word in sentenceWord if word in noList])>0):
			# send all the job and cover letter link to user
					sendJobUrl(msg)
					emailFlag = False
					users.daily_select = 1
					db.session.commit()
					reply = TextReply(content="You can download all the cover letters.", message=msg)
					return reply
					

			if emailFlag:
				reply = TextReply(content="Sorry, we can\'t understand what you say. If you want to send email, please reply 'yes'", message=msg)

		else:
			replyResult = SayHello(msg)
			reply = TextReply(content=replyResult, message=msg)
			# startSend()
		return reply

		

def handleSubscribeScanEvent(e):
	goeasy_url = "http://rest-singapore.goeasy.io/publish"
	result_data = {
	  "status":"success",
	  "openid": e.source,
	  "type":0
	}
	data = {'appkey':'BC-1c13a3ef799341a086581fad211cd278',
					  'channel':e.ticket,
					  'content':json.dumps(result_data)}
	
	r = requests.post(goeasy_url,data)
	user = User.query.filter_by(openid=e.source).first()
	if not user or user._password == "":
		with db.auto_commit():
			user = User()
			user.openid = e.source
			db.session.add(user)
		wechat_sender('Subscribe Successfully',e.source)
		wechat_sender('Please fill in the register form first.',e.source)
	else:
		return TextReply(content='Login Successfully', message=e)

def handleScanEvent(e):
	goeasy_url = "http://rest-singapore.goeasy.io/publish"
	result_data = {
	  "status":"success",
	  "openid": e.source,
	  "type":1
	}
	user = User.query.filter_by(openid=e.source).first()
	if user and user.name == "":
	  result_data["type"] = 0
	data = {'appkey':'BC-1c13a3ef799341a086581fad211cd278',
					  'channel':e.ticket,
					  'content':json.dumps(result_data)}
	r = requests.post(goeasy_url,data)
	return TextReply(content='Login Successfully', message=e)


@api.route('/wechatQR', methods=['GET'])
def getWeChatQR():
	client = WeChatClient(current_app.config.get("WECHAT_APPID"), current_app.config.get("WECHAT_SECRET"))
	res = client.qrcode.create({
	  'expire_seconds': 1800,
	  'action_name': 'QR_SCENE',
	  'action_info': {
		'scene': {'scene_id': 123},
	  }
	})
	url = client.qrcode.get_url(res['ticket'])
	goeasy_url = "http://rest-singapore.goeasy.io/publish"
	data = {'appkey':'BC-1c13a3ef799341a086581fad211cd278',
					  'channel':res['ticket'],
					  'content':'scanQR'}
	r = requests.post(goeasy_url,data)
	result = {"qrcode_url":url,"channel":res['ticket']}
	return Success(msg=result)


#add by Zhang

#send text message
def wechat_sender(content,user_id):
	client = WeChatClient(current_app.config.get("WECHAT_APPID"), current_app.config.get("WECHAT_SECRET"))
	user = client.user.get(f'{user_id}')
	client.message.send_text(f'{user_id}', f'{content}')

# unsubscribe handle
def handleUnsubscribeEvent(e):
	#delete the file
	root = os.path.dirname(os.path.abspath(__file__))
	root = root + "\\htmlfile\\website\\"
	file_name = "%s_JobPosition.html" % e.source
	if(os.path.exists(root+file_name)):
		os.remove(root+file_name)

def sendJobUrl(msg):
	jobs =Job.query.filter_by(u_id=users.id,status=3).all()
	urlNgrok = current_app.config.get("WECHAT_NGROK")
	for job in jobs:
		wechat_sender(job.title,msg.source)
		wechat_sender(urlNgrok+'/api/v1/coverletter/getJobPDF?job_id='+str(job.id),msg.source)
		coverletter = CoverLetter.query.filter_by(u_id=users.id,j_id=job.id).first()
		wechat_sender('CoverLetter',msg.source)
		wechat_sender(urlNgrok+'/api/v1/coverletter/getCoverLetterPDF?cv_id='+str(coverletter.id),msg.source)


def getAccessToken():
	url = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=%s&secret=%s' % (str(current_app.config.get("WECHAT_APPID")), str(current_app.config.get("WECHAT_SECRET")))
	r = requests.get(url)
	data = json.loads(r.text)
	access_token = data['access_token']
	return access_token

# menu handle
def handleMenuEvent(e):
	if e.key == "V1001_TODAY_WEBSITE":
		wechat_sender("Our website is " + "http://159.138.99.244:9528/#/user",e.source)
	if e.key == "V1001_TODAY_ABOUT":
		wechat_sender("This is the WeChat Subscription of Intelligent Job Hunter. \n\r Our team members: \n\r XU JIACHEN \n\r LI XILNIN \n\r ZHANG ZHILIN \n\r NRMALENDU PRAKASH",e.source)

# main function
# add in task
def startSend():
	client = WeChatClient(current_app.config.get("WECHAT_APPID"), current_app.config.get("WECHAT_SECRET"))
	getOpenId(client)


#get openid and enroll in message join
def getOpenId(client):
	for openid in client.user.iter_followers():
		user = User.query.filter_by(openid = openid).first()
		if user:
			flag = sendMessageTemplate(openid,client)
			
			if isinstance(flag,int):
				if flag<0:
					print("no job")
			elif flag['errcode'] == 0:
				print(' [INFO] send to %s is success' % openid)
			else:
				print(' [ERROR] send to %s is error' % openid)
		

# visit by user, not func
@api.route('/JPhtml', methods=['GET'])
def visitHtml():
	form = GenerateWechatHtmlForm().validate_for_api()
	openid = form.openid.data

	#get timestamp
	timStamp = request.args.get('timestamp')
	timStampNow = calTimeStamp()


	if str(timStampNow) == str(timStamp):

		user = User.query.filter_by(openid = openid).first()
		#, status = 0 or 1 or 2 or 3
		jobs = Job.query.filter_by(u_id=user.id,status = 1).all()

		# build html
		html_message = ""
		if user.daily_select == 0:
			html_message = buildHtml(jobs,openid)
		else:
			html_message = buildEmptyHtml()
		
	else:
		html_message = buildOverDueHtml()
	return html_message
	


	# return send_from_directory(root, "%s_JobPosition.html" % openid)

@api.route('/JPhtml/select', methods=['GET'])
def postHtml():
	form = GenerateWechatHtmlForm().validate_for_api()
	openid = form.openid.data
	
	result = request.args.get('result')
	result_list = []
	if(len(result)>3):
		#Change the status of user,for the moment 1 as submit 0 as unsubmit
		user = User.query.filter_by(openid=openid).first()
		user.daily_select = 1
		db.session.commit()


		result_list = result.split(",")
		result_list = result_list[0:-1]
		job_id_list = []
		str_answer = ""
		for str_id in result_list:
			job_id_list.append(int(str_id.replace("#btn","")))
			str_answer = str_answer+" " + str_id.replace("#btn","")

		#Change job status ,for the moment 0,input 1,recommend 2,post to user 3.user submit

		for job_id in job_id_list:
			job = Job.query.filter_by(id = job_id).first()
			job.status = 2
			db.session.commit()

		wechat_sender("Thank you for your submission.",openid)
		wechat_sender("We have already build your cover letter, please open the link below at your laptop or PC.",openid)
		wechat_sender("http://159.138.99.244:9528/#/course/coverletter?uid="+str(user.id),openid)
		
	return Success()

# send template to users
def sendMessageTemplate(openid,client):
	from app.models.resume import Resume
	templateId = current_app.config.get("WECHAT_TEMPLATEID")
	urlNgrok = current_app.config.get("WECHAT_NGROK")
	print(openid)

	user = User.query.filter_by(openid = openid).first()

	if user:
		resume = Resume.query.filter_by(u_id=user.id).first()

		if (resume == None or user.monitor_email_account == '' or user.monitor_email_password == ''):
			wechat_sender("Please complete your personal profile on our website first!" + "http://159.138.99.244:9528/#/user",openid)
			return -1
		else:
			#, status = 0
			jobs = Job.query.filter_by(u_id=user.id,status=1).all()
			if(len(jobs)<1):
				wechat_sender("There have no job opportunities today. Have a nice day!",openid)
				return -1
				# This part dont need to return, will it warning in python?
			else:
				# get time stamp
				timStamp = calTimeStamp()
				# combine the url
				url = urlNgrok+'/api/v1/wechat/JPhtml?openid='+openid + "&" + "timestamp=" + timStamp
				print(url)
				msg = {
						'touser': openid,
						'template_id': templateId,
						'url': url,
						'data': {
							'content': {
								'value': timeJudge() + '%s, check your daily job opportunities' % ("Mr" if user.gender.upper().find('FEMALE')<0 else "Mrs"),
								'color': '#0000CD'
								}
						}
					}


				json_data = json.dumps(msg)
				access_token = getAccessToken()
				url = 'https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=%s' % str(access_token)
				r = requests.post(url, json_data)

				#change user status after change send new template
				user.daily_select = 0
				db.session.commit()


				return json.loads(r.text)

# function to calculate timestamp
def calTimeStamp():
	# get today
	today = datetime.date.today()#2018-01-17
	dt = str(today) + " 00:00:00"
	#change to timestamp
	timeArray = time.strptime(dt, "%Y-%m-%d %H:%M:%S")
	timStamp = int(time.mktime(timeArray))
	return str(timStamp)

def SayHello(msg):
	from app.models.resume import Resume
	hellowWord = ["hi","hello"]
	sentenceWord = word_tokenize(msg.content.lower())
	
	if(len([word for word in sentenceWord if word in hellowWord])>0):
		#if not complete the profile
		user = User.query.filter_by(openid = msg.source).first()
		if user:
			resume = Resume.query.filter_by(u_id=user.id).first()
			if (resume == None or user.monitor_email_account == '' or user.monitor_email_password == ''):
				return timeJudge() + "this is Intelligent Job Hunter. Please complete your personal profile on our website first!" + "http://159.138.99.244:9528/#/user"
		return timeJudge() + "this is Intelligent Job Hunter. We will hunt your job opportunities everyday"
	else:
		return "Sorry, we can\'t understand what you say."

def timeJudge():
	
	if int(time.localtime().tm_hour)<12:
		return "Good morning, "
	elif int(time.localtime().tm_hour)<17:
		return "Good afternoon, "
	else:
		return "Good evening, "