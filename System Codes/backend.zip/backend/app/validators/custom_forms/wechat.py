from wtforms import StringField, IntegerField, DateField, FieldList
from wtforms.validators import DataRequired, length, Regexp
from wtforms import ValidationError
from app.validators.base import BaseForm
from wtforms.validators import DataRequired


class GetWechatQRcodeForm(BaseForm):
  uuid = StringField(validators=[DataRequired()])

class GenerateWechatHtmlForm(BaseForm):
  openid =  StringField(validators=[DataRequired()])
