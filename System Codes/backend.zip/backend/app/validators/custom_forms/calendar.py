from wtforms import StringField, IntegerField, DateField, FieldList
from wtforms.validators import DataRequired, length, Regexp
from wtforms import ValidationError
from app.validators.base import BaseForm
from wtforms.validators import DataRequired

class GetCalendarByCidForm(BaseForm):
  course_id = StringField(validators=[DataRequired()])
