from wtforms import StringField, IntegerField, DateField, FieldList
from wtforms.validators import DataRequired, length, Email, Regexp
from wtforms import ValidationError
from app.validators.base import BaseForm
from wtforms.validators import DataRequired

class getCoverLetterDataForm(BaseForm):
    uid = StringField(validators=[DataRequired()])

class getCoverLetterPDFForm(BaseForm):
    cv_id = StringField(validators=[DataRequired()])

class uploadCoverLetterDataForm(BaseForm):
    id = IntegerField(validators=[DataRequired()])
    sender_name = StringField(validators=[DataRequired()])
    sender_phone = StringField(validators=[DataRequired()])
    sender_email = StringField(validators=[
        Email(message='invalidate email')
    ])
    recipiant_title = StringField(validators=[DataRequired()])
    first_paragraph = StringField(validators=[DataRequired()])
    secend_paragraph = StringField(validators=[DataRequired()])
    third_paragraph = StringField(validators=[DataRequired()])
    fourth_paragraph = StringField(validators=[DataRequired()])

class submitJobCVSelectionForm(BaseForm):
    password = StringField(validators=[DataRequired()])
    jobs = FieldList(StringField(
        validators=[DataRequired()]), min_entries=1,)


# class uploadresumeDataForm(BaseForm):
#     password = StringField(validators=[DataRequired()])
#     id = IntegerField(validators=[DataRequired()])
#     name = StringField(validators=[DataRequired()])
#     phone = StringField(validators=[DataRequired()])
#     email = StringField(validators=[
#         Email(message='invalidate email')
#     ])
#     resume_type = FieldList(StringField(
#         validators=[DataRequired()]), min_entries=1,)
#     education_experience = StringField()
#     project_experience = StringField()


# class AddUserForm(BaseForm):
#     name = StringField(validators=[DataRequired()])
#     email = StringField(validators=[
#         Email(message='invalidate email')
#     ])
#     auth = StringField(validators=[DataRequired()])


# class UploadMonitorEmail(BaseForm):
#     password = StringField(validators=[DataRequired()])
#     monitor_email_account = StringField(validators=[
#         Email(message='invalidate email')
#     ])
#     monitor_email_password = StringField(validators=[DataRequired()])

# class UpdateUserForm(BaseForm):
#     id = IntegerField(validators=[DataRequired()])
#     name = StringField(validators=[DataRequired()])
#     domain = StringField(validators=[DataRequired()])
#     password = StringField(validators=[DataRequired()])
#     age = IntegerField(validators=[DataRequired()])
#     gender = StringField(validators=[DataRequired()])
#     email = StringField(validators=[
#         Email(message='invalidate email')
#     ])

# class UpdatePasswordForm(BaseForm):
#     oldpwd = StringField(validators=[DataRequired()])
#     newpwd = StringField(validators=[DataRequired()])


# class TokenForm(BaseForm):
#   token = StringField(validators=[DataRequired()])

# class UserInfoSearchForm(BaseForm):
#     name = StringField()
#     auth = StringField()


# class RegisterForm(BaseForm):
#     name = StringField(validators=[DataRequired()])
#     password = StringField(validators=[DataRequired()])
#     email = StringField(validators=[
#         Email(message='invalidate email')
#     ])
#     gender = StringField(validators=[DataRequired()])
#     age = IntegerField(validators=[DataRequired()])
#     color = StringField(validators=[DataRequired()])

# class RegisterForm(BaseForm):
#     openid = StringField(validators=[DataRequired()])
#     name = StringField(validators=[DataRequired()])
#     password = StringField(validators=[DataRequired()])
#     email = StringField(validators=[
#         Email(message='invalidate email')
#     ])
#     gender = StringField(validators=[DataRequired()])
#     age = IntegerField(validators=[DataRequired()])