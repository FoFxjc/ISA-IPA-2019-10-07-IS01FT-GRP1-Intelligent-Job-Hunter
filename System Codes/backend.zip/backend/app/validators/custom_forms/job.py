from wtforms import StringField, IntegerField, DateField, FieldList
from wtforms.validators import DataRequired, length, Email, Regexp
from wtforms import ValidationError
from app.validators.base import BaseForm
from wtforms.validators import DataRequired

class getJobPDFForm(BaseForm):
    job_id = StringField(validators=[DataRequired()])
