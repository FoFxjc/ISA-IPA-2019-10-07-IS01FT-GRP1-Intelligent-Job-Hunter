from wtforms import StringField, IntegerField, DateField, FieldList
from wtforms.validators import DataRequired, length, Regexp
from wtforms import ValidationError
from app.validators.base import BaseForm
from wtforms.validators import DataRequired

class AppointmentCalculateForm(BaseForm):
  type = StringField(validators=[DataRequired()])
  point_reading = StringField(validators=[DataRequired()])
  point_writing = StringField(validators=[DataRequired()])
  point_listening = StringField(validators=[DataRequired()])
  point_speaking = StringField(validators=[DataRequired()])
  target_speaking = StringField(validators=[DataRequired()])
  target_reading = StringField(validators=[DataRequired()])
  target_writing = StringField(validators=[DataRequired()])
  target_listening = StringField(validators=[DataRequired()])

class AppointmentAddForm(BaseForm):
  id = IntegerField()
  course_id = IntegerField(validators=[DataRequired()])
  course_type = StringField(validators=[DataRequired()])
  point_speaking = StringField(validators=[DataRequired()])
  point_reading = StringField(validators=[DataRequired()])
  point_writing = StringField(validators=[DataRequired()])
  point_listening = StringField(validators=[DataRequired()])
  point_total = StringField(validators=[DataRequired()])
  target_speaking = StringField(validators=[DataRequired()])
  target_reading = StringField(validators=[DataRequired()])
  target_writing = StringField(validators=[DataRequired()])
  target_listening = StringField(validators=[DataRequired()])
  target_total = StringField(validators=[DataRequired()])
  recommend_speaking = IntegerField(validators=[DataRequired()])
  recommend_reading = IntegerField(validators=[DataRequired()])
  recommend_writing = IntegerField(validators=[DataRequired()])
  recommend_listening = IntegerField(validators=[DataRequired()])
  stu_adjustments = FieldList(IntegerField())

class AppointmentSearchByStuidandCourseid(BaseForm):
  stu_id = IntegerField(validators=[DataRequired()])
  course_id = IntegerField(validators=[DataRequired()])

class AppointmentSearchByCourseid(BaseForm):
  course_id = IntegerField(validators=[DataRequired()])

class AppointmentSearchForm(BaseForm):
  course_id = IntegerField()
  type = StringField()
  stu_name = StringField()
  status = IntegerField()

class updateAppoinmentStatusForm(BaseForm):
  app_id = IntegerField(validators=[DataRequired()])
  status = IntegerField(validators=[DataRequired()])

