from wtforms import StringField, IntegerField, DateField, FieldList
from wtforms.validators import DataRequired, length, Regexp
from wtforms import ValidationError
from app.validators.base import BaseForm
from wtforms.validators import DataRequired

class CourseAddForm(BaseForm):
  id = IntegerField()
  name = StringField(validators=[DataRequired()])
  types = FieldList(StringField(
        validators=[DataRequired()]), min_entries=1,)
  start_date = DateField(validators=[DataRequired()])
  end_date = DateField(validators=[DataRequired()])
  app_deadline = DateField(validators=[DataRequired()])
  classes_num_limited = IntegerField(validators=[DataRequired()])
  personal_adjustments = FieldList(IntegerField())
  detail = StringField(validators=[DataRequired()])

class CourseSearchForm(BaseForm):
  id = IntegerField()

class AskForSchedulerResultForm(BaseForm):
  id = StringField(validators=[DataRequired()])

class doSchedulerResultForm(BaseForm):
  id = StringField(validators=[DataRequired()])

class GetTotalClassNum(BaseForm):
  start_date = DateField(validators=[DataRequired()])
  end_date = DateField(validators=[DataRequired()])
  adjustments = FieldList(IntegerField())