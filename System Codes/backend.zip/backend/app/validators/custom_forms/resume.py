from wtforms import StringField, IntegerField, DateField, FieldList
from wtforms.validators import DataRequired, length, Email, Regexp
from wtforms import ValidationError
from app.validators.base import BaseForm
from wtforms.validators import DataRequired

class getresumePDFForm(BaseForm):
    uid = StringField(validators=[DataRequired()])

class uploadresumeDataForm(BaseForm):
    password = StringField(validators=[DataRequired()])
    id = IntegerField(validators=[DataRequired()])
    name = StringField(validators=[DataRequired()])
    phone = StringField(validators=[DataRequired()])
    email = StringField(validators=[
        Email(message='invalidate email')
    ])
    resume_type = FieldList(StringField(
        validators=[DataRequired()]), min_entries=1,)
    education_experience = StringField()
    project_experience = StringField()
