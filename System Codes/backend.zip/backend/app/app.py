"""
 Create by jiachenx on 2019/3/11
"""
from flask import Flask as _Flask
from flask.json import JSONEncoder as _JSONEncoder
from app.libs.error_code import ServerError
from datetime import date
import os

APP_ROOT = os.path.dirname(os.path.abspath(__file__))

__author__ = 'jiachenx'

class JSONEncoder(_JSONEncoder):
  def default(self, o):
    if hasattr(o, 'keys') and hasattr(o, '__getitem__'):
      return dict(o)
    if isinstance(o,date):
      return o.isoformat()
    raise ServerError()

class Flask(_Flask):
  json_encoder = JSONEncoder
