import tagui as t
# from getaccount import get_account
import app.rpa.tagui_util as util
import zipfile
import shutil
from app.models.base import db
from app.models.job import Job
import os
import time
import re

# usr_id,usr_pwd=get_account()

def outlook_login(email_account,email_pwd):
    # usr_email = usr_id + '@u.nus.edu'
    print("The processing user email is:",email_account)
    # t.init()
    t.url('https://outlook.com/u.nus.edu')

    t.type('//input[@id="ContentPlaceHolder1_UsernameTextBox"]', email_account)
    t.wait(0.5)
    t.type('//input[@id="ContentPlaceHolder1_PasswordTextBox"]', email_pwd + '[enter]')
    t.wait(1)
    t.click('//input[@id="idBtn_Back"]')
    t.wait(2)

def outlook_filter():
    t.click('//input[@placeholder="Search"]')

    # t.type('//span[@class="AfkHF5Y6JnnGWIFCEtB7k"]','luminus-do-not-reply@nus.edu.sg, job opportunity')
    # t.click('//input[@aria-label="Search"]')
    # t.keyboard('[enter]')
    # t.wait(2)
    t.click('//span[@class="AfkHF5Y6JnnGWIFCEtB7k"]')
    t.type('(//input[@id="From-PICKER-ID"])','luminus-do-not-reply@nus.edu.sg' + '[enter]')
    # t.type('(//input[@id="From-PICKER-ID"])','nustalentconnect@csm.symplicity.com' + '[enter]')
    t.wait(1)
    t.type('//input[@id="Keywords-ID"]','job opportunity')
    t.wait(1)
    t.click('(//input[@placeholder="Select a date"])[1]')
    # format_date=time.strftime('%B %d, %Y',time.localtime())

    format_date="September 30, 2019"

    t.click(f'//button[@aria-label=\"{format_date}\"]')
    t.wait(1)
    t.click('(//input[@placeholder="Select a date"])[2]')
    t.click(f'//button[@aria-label=\"{format_date}\"]')


    t.click('//button[@aria-label="Search"]')
    t.wait(3)
    # t.click('//span[@class="ms-Button-label label-200"][1]')
    # t.click('ol_filter_search.png')

def outlook_process():
    num_email=t.count('//div[@class="_1hHMVrN7VV4d6Ylz-FsMuP _18LAllQi61d4a4XNAr9prg"]')
    print('The number of job opportunity emails from luminus is: ',num_email)

    mail_link = []
    luminus_folder=[]
    luminus_link=[]
    filename=[]
    #get all luminus links
    for n in range(1,num_email+1):
        t.click(f'(//div[@class="_1hHMVrN7VV4d6Ylz-FsMuP _18LAllQi61d4a4XNAr9prg"])[{n}]')
        mail_link.append(t.url())
        luminus_folder.append(util.hover_and_read('//a[@target="_blank"]'))
        luminus_link.append(util.hover_and_read('//a[@target="_blank"]/@href'))
        content= t.read('(//font[@face="verdana"]/text())[4]')
        filename.append(content.split(": ")[1])
        print(filename[n-1])
        # _confent = content.split("\n")

        # print("The email content: ",content)

        # for _line in _confent:
        #     if re.match('^File Name',_line):
        #         filename.append(_line.split(": ")[1])
    print("Thoes mails' links containing job opportunity from luminus: ",mail_link)
    print("Thoes job opportunities' folder name from luminus: ",luminus_folder)
    print("Thoes job opportunities' luminus links: ",luminus_link)

    return mail_link,luminus_folder,luminus_link,filename

def outlook_logout():
    t.click('//div[@class="_14ggU2yZvNol5U91gfmYQA"]')
    t.click('//a[@title="Sign out and return to the Sign-in page"]')
    t.wait(5)

def luminus_login(email_account,email_pwd):
    # t.url('https://luminus.nus.edu.sg/')
    # t.wait(1)
    t.click('(//a[@class="btn btn-primary btn-login"])[1]')
    luminus_account=email_account.split('@')[0]
    t.type('//input[@id="userNameInput"]','nusstu\\'+luminus_account)
    t.type('//input[@id="passwordInput"]',email_pwd + '[enter]')

def luminus_process(email_account,email_pwd,luminus_link,data_execute_path,usr_id,filename):
    date = time.strftime("%Y%m%d", time.localtime())
    folder_name = os.path.join(data_execute_path, str(usr_id)+"/jobposition/"+date+"/")
    print(folder_name)
    if not os.path.exists(folder_name):
        os.makedirs(folder_name)

    t.init()
    for n in range(len(luminus_link)):
        # t.init()
        t.url(luminus_link[n])
        luminus_login(email_account,email_pwd)
        # if n==0:
        #     luminus_login(email_account,email_pwd)
  
        t.type('//input[@placeholder="Search files"]',filename[n])
        print("luminus search for: ",filename[n])
        t.wait(2)
        # t.click('//div[@class="select ng-star-inserted"]')
        
        num_file=t.count('//span[@class="filename"]')
        all_file=[]
        for i in range(num_file):
            all_file.append(util.hover_and_read(f'(//span[@class="filename"])[{i+1}]'))

        flag=1
        for i in range(len(all_file)):
            if all_file[i]==filename[n]:
                flag=i+1
            else:
                pass
        print("luminus search result: ",all_file)
        t.click(f'(//div[@class="select disable-select ng-star-inserted"])[{flag}]')

        t.click('(//a[@class="tool ng-star-inserted"])[4]')
        t.wait(5)
        
        print(os.getcwd())

        shutil.move(f"{filename[n]}",f"{n}-{filename[n]}")
        shutil.move(f"{n}-{filename[n]}", folder_name)

        # if num_file==1:
        #     shutil.move(f"{filename}",f"{n}-{filename}")
        #     shutil.move(f"{n}-{filename}", folder_name)
        # else:
        #     #select box (//div[@class="select disable-select ng-star-inserted"])[2]
        #     shutil.move("selected-downloads.zip",f"selected-downloads-{n}.zip")
        #     shutil.move(f"selected-downloads-{n}.zip", folder_name)
        #     z = zipfile.ZipFile(folder_name+f"/selected-downloads-{n}.zip", 'r')
        #     z.extractall(path=folder_name)
        #     z.close()

        # rename to avoid duplicate filename ---------------------------------check file download location
        # shutil.move(f"{filename}",f"{n}-{filename}")

        # shutil.move(f"{n}-{filename}", folder_name)
        # z = zipfile.ZipFile(folder_name+f"/selected-downloads-{n}.zip", 'r')
        # z.extractall(path=folder_name)
        # z.close()

        # t.click('//a[@tooltip="Sign out"]')
        # t.close()
    t.close()

    path = folder_name
    filename_list = os.listdir(path)
    job_path = []

    for i in range(len(filename_list)):
        new_path = os.path.join(path, filename_list[i])
        if os.path.isfile(new_path):
            if new_path.endswith('.pdf'):
                job_path.append(new_path)

    for j in range(len(job_path)):
        with db.auto_commit():
            job = Job()
            job.u_id = usr_id
            job.file_location = job_path[j]
            job.url = luminus_link[j]
            job.status = 0
            title=filename[j].split('.')[0]
            job.title = title

            db.session.add(job)





# outlook_login()
# outlook_filter()
# mail_link,luminus_folder,luminus_link=outlook_process()
#
# luminus_process(luminus_link)
# t.close()