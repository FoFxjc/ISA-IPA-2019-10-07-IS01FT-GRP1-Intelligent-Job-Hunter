from app.models.user import User

def get_account():
    users = User.query.filter_by().all()

    usr_id=[]
    email_account=[]
    email_pwd=[]
    for user in users:
        usr_id.append(user.id)
        email_account.append(user.monitor_email_account)
        email_pwd.append(user.monitor_email_password)

    return usr_id,email_account,email_pwd