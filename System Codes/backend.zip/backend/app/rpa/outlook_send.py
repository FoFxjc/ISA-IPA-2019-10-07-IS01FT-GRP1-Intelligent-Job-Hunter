import win32com.client as win32
import warnings
# import sys
import importlib,sys
import pythoncom




def sendmail(company_email,resume_path,coverletter_path,usr_email,usr_name,job_pst):
    importlib.reload(sys)
    # reload(sys)
    # sys.setdefaultencoding('utf8')
    warnings.filterwarnings('ignore')
    pythoncom.CoInitialize()
    sub = usr_name+' applying for '+job_pst
    body = 'Dear hiring manager,\r\n\r\n I am '+usr_name+' and I want to apply for '+job_pst+'\r\n The enclosed resume and cover letter outline my credentials and accomplishments in greater detail. I would welcome an opportunity to meet with you for a personal interview. \r\n\r\n Best regards, \r\n'+usr_name
    outlook = win32.Dispatch('outlook.application')
    receivers = [company_email]
    mail = outlook.CreateItem(0)
    mail.To = receivers[0]
    mail.Subject = sub
    mail.Body = body
    mail.Attachments.Add(resume_path)
    mail.Attachments.Add(coverletter_path)
    # mail.CC(usr_email)
    mail.Send()

# sendmail("e0402032@u.nus.edu","C:\\IPA\\backend\\app\\data\\3\\resume\\XUJIACHEN.pdf","C:\\IPA\\backend\\app\\data\\3\\coverletter\\20191025\\coverletter_14.pdf","e0402060@u.nus.edu")