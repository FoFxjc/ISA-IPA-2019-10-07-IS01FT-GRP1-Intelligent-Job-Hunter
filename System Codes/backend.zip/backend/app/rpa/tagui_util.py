import tagui as t

def hover_and_read(selector):
    t.hover(selector)
    str = t.read(selector)
    return str