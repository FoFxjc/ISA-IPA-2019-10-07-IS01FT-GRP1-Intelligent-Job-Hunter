from sqlalchemy import Column, String, Integer, orm, ForeignKey
from sqlalchemy.orm import relationship, backref
from sqlalchemy.dialects.mysql import LONGTEXT, DATE
from app.models.base import Base


class CoverLetter(Base):

    __tablename__ = 'coverletter'

    id = Column(Integer, primary_key=True, autoincrement=True)
    u_id = Column(Integer, ForeignKey('user.id'))
    user = relationship('User', foreign_keys=[
        u_id], backref=backref('CoverLetter'))
    j_id = Column(Integer, ForeignKey('job_position.id'))
    job = relationship('Job', foreign_keys=[
        j_id], backref=backref('CoverLetter'))
    cover_letter_data = Column(LONGTEXT, nullable=False)
    cover_file_location_origin = Column(LONGTEXT, nullable=False)
    cover_file_location_after = Column(LONGTEXT, nullable=True)
    status =  Column(Integer, nullable=False)

    @orm.reconstructor
    def __init__(self):
        Base.__init__(self)
        self.fields = ['create_time', 'id', 'u_id', 'j_id','cover_letter_data',
                       'cover_file_location_origin', 'cover_file_location_after','status']