from sqlalchemy import Column, String, Integer, orm, ForeignKey
from sqlalchemy.orm import relationship, backref
from sqlalchemy.dialects.mysql import LONGTEXT, DATE
from app.models.base import Base


class Job(Base):

    __tablename__ = 'job_position'

    id = Column(Integer, primary_key=True, autoincrement=True)
    u_id = Column(Integer, ForeignKey('user.id'))
    user = relationship('User', foreign_keys=[
        u_id], backref=backref('Job'))
    type = Column(String(30), nullable=True)
    title = Column(LONGTEXT, nullable=False)
    company_email = Column(LONGTEXT, nullable=True)
    company_name = Column(LONGTEXT, nullable=True)
    description = Column(LONGTEXT, nullable=True)
    requirement = Column(LONGTEXT, nullable=True)
    location = Column(String(200), nullable=True)
    salary = Column(String(15), nullable=True)
    file_location = Column(LONGTEXT, nullable=True)
    url = Column(LONGTEXT, nullable=True)
    status =  Column(Integer, nullable=False)

    @orm.reconstructor
    def __init__(self):
        Base.__init__(self)
        self.fields = ['create_time', 'id', 'u_id', 'title','type',
                       'company_name', 'description','requirement','company_email',
                       'location', 'salary', 'file_location','url','status']