from sqlalchemy import Column, String, Integer, orm, ForeignKey
from sqlalchemy.orm import relationship, backref
from sqlalchemy.dialects.mysql import LONGTEXT, DATE
from app.models.base import Base


class Resume(Base):

    __tablename__ = 'resume'

    id = Column(Integer, primary_key=True, autoincrement=True)
    u_id = Column(Integer, ForeignKey('user.id'))
    user = relationship('User', foreign_keys=[
        u_id], backref=backref('Resume'))
    name = Column(String(200), nullable=True)
    phone = Column(String(20), nullable=True)
    email = Column(String(30), nullable=True)
    resume_type = Column(String(30),nullable=False)
    education_experience = Column(LONGTEXT, nullable=True)
    project_experience = Column(LONGTEXT, nullable=True)
    resume_location = Column(LONGTEXT, nullable=True)
    status =  Column(Integer, nullable=False)

    @orm.reconstructor
    def __init__(self):
        Base.__init__(self)
        self.fields = ['create_time', 'id', 'u_id', 'name','resume_type',
                       'phone', 'email',
                       'education_experience', 'project_experience', 'resume_location','status']