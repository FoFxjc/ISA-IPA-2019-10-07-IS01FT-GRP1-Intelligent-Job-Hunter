#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   scope.py
@Time    :   2019/03/12 12:25:00
@Author  :   Jiachen Xu
@Desc    :   None
'''


def is_in_scope(scope, endpoint):
    # scope = globals()[scope]()
    return True
    # splits = endpoint.split('+')
    # red_name = splits[0]
    # if endpoint in scope.forbidden:
    #     return False
    # if endpoint in scope.allow_api:
    #     return True
    # if red_name in scope.allow_module:
    #     return True
    # else:
    #     return False


def is_in_allow_actions(scope, action, isself=True):
    scope = globals()[scope]()
    if isself:
        if action in scope.allow_action_self:
            return True
        else:
            return False
    else:
        if action in scope.allow_action:
            return True
        else:
            return False
