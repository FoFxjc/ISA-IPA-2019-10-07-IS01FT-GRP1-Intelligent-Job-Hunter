
import math

class DecisionTree():


  def __init__(self,module_type,test_type):
    self.module_type = module_type
    self.test_type = test_type

  def do_decision(self,module_point,module_target_point,stu):
    decision_function = getattr(self, self.test_type.lower() + '_' + self.module_type.lower())
    (_min,_max) = decision_function(stu.gender,int(stu.age),module_point,module_target_point)
    if _min == 0:
      return _max
    return  math.ceil((_min+_max)/2)
    

  def ielts_writing(self,gender,age,module_point,module_target_point):
    difference_value = module_target_point - module_point
    if age >= 12 and age <=15:
        return (15,19)
    if age >= 16 and age <=18:
        if module_point >= 4.5:
          return (15,19)
        else:
          return (10,14)
    if age >= 19 and age <=22:
      if gender == "male":
        return (10,14)
      elif gender == "female":
        if difference_value <= 0.0:
          return (0,4)
        else:
          if module_point <= 5.0:
            return (10,14)
          else:
            return (10,14)
    if age >=23 and age <=25:
      if module_point <= 5.5:
        return (5,9)
      else:
        if gender == "female":
          return (5,9)
        else:
          return (5,9)
      
  def ielts_speaking(self,gender,age,module_point,module_target_point):
    difference_value = module_target_point - module_point
    if age >= 12 and age <=15:
        return (20,24)
    if age >= 16 and age <=18:
        if difference_value <= 0.5:
          if difference_value <= 0.0:
            return (0,4)
          else:
            if gender == "female":
              return (15,19)
            elif gender == 'male':
              if module_point <= 5.0:
                return (20,24)
              else:
                return (20,24)
        else:
          return (30,39)
    if age >= 19 and age <=22:
      if difference_value <= 0.0:
        return (0,4)
      else:
        if gender == "female":
          if module_point <= 5.0:
            return (10,14)
          else:
            return (10,14)
        elif gender == "male":
          if module_point <= 5.5:
            return (15,19)
          else:
            return (15,19)
      if age >=23 and age <=25:
        if gender == "female":
          return (10,14)
        elif gender == 'male':
          return (10,14)

  def ielts_listening(self,gender,age,module_point,module_target_point):
    difference_value = module_target_point - module_point
    print(difference_value,gender,age,module_point,module_target_point)
    if difference_value <= 0.5:
      if age >= 12 and age <= 15:
        return (10,14)
      if age >= 16 and age <=18:
        if module_point <= 5.5:
          return (10,14)
        else:
          if gender == "female":
            return (5,9)
          elif gender == 'male':
            return (10,14)
      if age >= 19 and age <=22:
        return (5,9)
      if age >=23 and age <=25:
        if module_point <= 6.5:
          return (5,9)
        else:
          return (5,9)
    elif difference_value > 0.5:
      if gender == "female":
        if difference_value <= 1.0:
          return (10,14)
        else:
          return (5,9)
      elif gender == 'male':
        # add
        if age >= 16 and age <=18:
          return (15,19)
        # error
        if age >=19 and age <= 22:
          return (15,19)
        if age >=23 and age <= 25:
          return (10,14)

  def ielts_reading(self,gender,age,module_point,module_target_point):
    difference_value = module_target_point - module_point
    if age >= 12 and age <=15:
      if module_point <= 5.5:
        return (20,24)
      else:
        return (15,19)
    if age >= 16 and age <=18:
        if difference_value <= 0.5:
          return (10,14)
        else:
          return (25,19)
    if age >= 19 and age <=22:
      if difference_value <= 0.5:
        if difference_value <=0:
          return (0,4)
        else:
          return (5,9)
      else:
        if gender == "female":
          return (15,19)
        elif gender == "male":
          return (15,19)
    if age >=23 and age <=25:
      if difference_value <= 0.0:
        return (0,4)
      else:
        if gender == "female":
          return (0,4)
        elif gender == 'male':
          return (0,4)

  def toefl_writing(self,gender,age,module_point,module_target_point):
    difference_value = module_target_point - module_point
    if difference_value <= 5.0:
      if difference_value <= 3.0:
        if age >= 16 and age <= 18:
          return (10,14)
        if age >= 19 and age <= 22:
          if difference_value <= 0.0:
            return (0,0)
          else:
            if gender == "female":
              return (5,9)
            elif gender == 'male':
              if difference_value <= 2.0:
                return (10,14)
              else:
                return (10,14)
        if age >= 23 and age <= 25:
          if gender == "female":
              return (5,9)
          elif gender == 'male':
            if difference_value <= 1.0:
              return (5,9)
            else:
              return (5,9)
      else:
          if age >= 16 and age <= 18:
            if module_point <= 17:
              return (10,14)
            else:
              return (10,14)
          if age >= 19 and age <= 22:
            return (10,14)
          if age >= 23 and age <= 25:
            return (10,14)
    else:
      if difference_value <= 9.0:
        if difference_value <= 6.0:
            return (10,14)
        else:
          if module_point <= 16:
            if gender == "female":
              return (10,14)
            elif gender == 'male':
              return (15,19)
          else:
            return (15,19)
      else:
          if difference_value <= 10.0:
            return (20,24)
          else:
            return (30,39)

  def toefl_speaking(self,gender,age,module_point,module_target_point):
    difference_value = module_target_point - module_point
    if age >= 12 and age <=15:
      if module_point <= 13.0:
        if module_point <= 10.0:
          return (10,14)
        else:
          return (20,24)
      else:
        return (15,19)
    if age >= 16 and age <=18:
      if difference_value <= 3.0:
        if gender == "female":
          return (5,9)
        elif gender == "male":
          return (0,4)
      else:
        if gender == "female":
          return (10,14)
        elif gender == "male":
          return (10,14)
      return (10,14)
    if age >= 19 and age <=22:
      if difference_value <= 6.0:
        if module_point <= 21.0:
          if module_point <= 20.0:
            return (10,14)
          else:
            return (10,14)
        else:
          if gender == "female":
            if difference_value <= 1.0:
              return (0,4)
            else:
              return (5,9)
          elif gender == "male":
            return (5,9)
      return  (5,9)
    if age >=23 and age <=25:
      return (15,19)

  def toefl_listening(self,gender,age,module_point,module_target_point):
    difference_value = module_target_point - module_point
    if age >= 12 and age <=15:
      if gender == "female":
        return (20,24)
      elif gender == "male":
        return (20,24)
    if age >= 16 and age <=18:
      if module_point <= 16.0:
        if gender == "female":
          return (15,19)
        elif gender == "male":
          return (5,9)
      else:
        if gender == "female":
          return (10,14)
        elif gender == "male":
          return (10,14)
    if age >= 19 and age <=22:
      if module_point <= 21.0:
        if module_point <= 18.0:
          return (10,14)
        else:
          if gender == "female":
            return (10,14)
          elif gender == "male":
            return (10,14)
      else:
        if difference_value <= 1.0:
          return (0,4)
        else:
          if difference_value <= 2.0:
            return (5,9)
          else:
            return (5,9)
    if age >=23 and age <=25:
      if difference_value <= 2.0:
        return (0,4)
      else:
        if gender == "female":
          return (5,9)
        elif gender == "male":
          return (5,9)

  def toefl_reading(self,gender,age,module_point,module_target_point):
    difference_value = module_target_point - module_point
    if age >= 12 and age <=15:
      if difference_value <= 10.0:
        return (15,19)
      else:
        return (20,24)
    if age >= 16 and age <=18:
      if difference_value <= 4.0:
        if module_point <= 21.0:
          return (10,14)
        else:
          if difference_value <= 1.0:
            return (5,9)
          else:
            return (5,9)
      else:
        if gender == "female":
          return (10,14)
        elif gender == "male":
          if module_point <= 18.0:
            return (10,14)
          else:
            return (10,14)
    if age >= 19 and age <=22:
      if difference_value <= 4.0:
        if difference_value <= 0.0:
          return (0,4)
        else:
          return (0,4)
      else:
        if difference_value <= 6.0:
          if gender == "female":
            return (5,9)
          elif gender == "male":
            return (5,9)
        else:
          return (5,9)
    if age >=23 and age <=25:
      return (0,4)