
def scan_startSend(app):
  with app.app_context():
    from app.api.v1.wechat import startSend
    startSend()

# ## 01:00
def collecttest(app):
  with app.app_context():
    from app.models.job import Job
    from app.models.base import db
    jobs = Job.query.filter(Job.status != 4).all()
    for job in jobs:
      job.status = 4
      db.session.commit()
    users = User.query.filter_by().all()
    for user in users:
      user.daily_select = 0
      db.session.commit()
    
    from app.rpa.getaccount import get_account
    from app.rpa.outlook_download import outlook_login,outlook_filter,outlook_process,luminus_process,outlook_logout
    import tagui as t
    import os

    from app.app import APP_ROOT
    data_execute_path = os.path.join(APP_ROOT, "data/")
    print(data_execute_path)
    usr_id, email_account, email_pwd=get_account()

   
    for i in range(len(usr_id)):
      if email_account[i] and email_pwd[i]:
        t.init()
        outlook_login(email_account[i],email_pwd[i])
        outlook_filter()
        mail_link, luminus_folder, luminus_link, filename = outlook_process()
        outlook_logout()
        t.close()
        t.wait(5)
        
        if len(mail_link):
          luminus_process(email_account[i],email_pwd[i],luminus_link, data_execute_path,usr_id[i],filename)
          #t.close()
        else:
          pass
      else:
        pass
    
    
    from app.models import job,resume,coverletter
    from app.models.base import db
    from app.app import APP_ROOT
    from app.nlp.IPA import ApplicantDB, Job, JobDB, Resume
    from app.nlp.CoverLetter import CoverLetter
    from app.models.user import User
    import time
    import os
    import shutil
    import subprocess
    from app.libs.utils import replace_char_for_latex
    jobs = job.Job.query.filter_by(status=0).all()
    date = time.strftime("%Y%m%d", time.localtime())
    nlp_execute_path = os.path.join(APP_ROOT, "nlp/")
    applicationDB = ApplicantDB(os.path.join(nlp_execute_path, "workex/"))
    roleDB=JobDB(os.path.join(nlp_execute_path, "JobResponsibility"))
    reqDB=JobDB(os.path.join(nlp_execute_path, "JobRequirement"))
    for item in jobs:
        filename = "temp.pdf"
        shutil.copy(item.file_location,
              os.path.join(nlp_execute_path, "exe/"+filename))
        _job = Job(os.path.join(nlp_execute_path, "exe/"+filename))
        _job.convert()
        jobtype,role,req = _job.extract(roleDB.documents,reqDB.documents)
        item.requirement = str(role)
        item.description = str(req)
        item.type = jobtype
        db.session.commit() 
    jobs = job.Job.query.filter_by(status=0).all()
    for item in jobs:
      _resume = resume.Resume.query.filter_by(u_id=item.u_id).first()
      if _resume.resume_type.find('[')>=0:
        _str = _resume.resume_type[1:-1]
        types = _str.split(',')
        _types = []
        for _temp in types:
          _types.append(_temp.strip()[1:-1])
        if item.type in _types:
          item.status = 1
          db.session.commit()
      else:
        if item.type == _resume.resume_type:
          item.status = 1
          db.session.commit()
    cv_temp_path = os.path.join(APP_ROOT, "nlp/coverletter_temp/")
    with open(os.path.join(cv_temp_path, "first_para.txt"),'r',encoding='utf-8') as f:
      para1=f.read()
    with open(os.path.join(cv_temp_path, "second_para.txt"),'r',encoding='utf-8') as f:
      para2=f.read()
    with open(os.path.join(cv_temp_path, "third_para.txt"),'r',encoding='utf-8') as f:
      para3=f.read()
    with open(os.path.join(cv_temp_path, "fourth_para.txt"),'r',encoding='utf-8') as f:
      para4=f.read()
    coverletter_generator = CoverLetter(para1,para2,para3,para4)
    users = User.query.filter_by().all()
    for user in users:
      jobs  = job.Job.query.filter_by(u_id=user.id,status=1).all()
      resume_sql = resume.Resume.query.filter_by(u_id=user.id).first()
      if len(jobs) != 0:
        _result =  coverletter_generator.create_letter(resume=resume_sql,jobs=jobs)
        for item in _result:
          # generate the coverletter
          sender_name = resume_sql.name
          sender_phone = resume_sql.phone
          sender_email = resume_sql.email
          recipiant_title = "Dear Sir or Madam"
          date = time.strftime("%B %d %Y", time.localtime()) 
          first_paragraph = item["jobs"][0]['letter'][0]
          secend_paragraph = item["jobs"][0]['letter'][1]
          third_paragraph = item["jobs"][0]['letter'][2]
          fourth_paragraph = item["jobs"][0]['letter'][3]
          template = open(os.path.join(APP_ROOT, "templates/templates.tex"), "r")
          content = template.read()
          content = content.replace('%[name]',sender_name)
          content = content.replace('%[phone]',sender_phone)
          content = content.replace('%[email]',sender_email)
          content = content.replace('%[date]',date)
          content = content.replace('%[recipiant_title]',recipiant_title)
          content = content.replace('%[first_paragraph]',replace_char_for_latex(first_paragraph,['%','#']))
          content = content.replace('%[secend_paragraph]',replace_char_for_latex(secend_paragraph,['%','#']))
          content = content.replace('%[third_paragraph]', replace_char_for_latex(third_paragraph,['%','#']))
          content = content.replace('%[fourth_paragraph]',replace_char_for_latex(fourth_paragraph,['%','#']))
          _cover_letter_data = {
            'sender_name' :sender_name,
            'sender_phone' :sender_phone,
            'sender_email' :sender_email,
            'recipiant_title' :recipiant_title,
            'date' :date,
            'first_paragraph' :first_paragraph,
            'secend_paragraph' :secend_paragraph,
            'third_paragraph' :third_paragraph,
            'fourth_paragraph' :fourth_paragraph,
          }
          date = time.strftime("%Y%m%d", time.localtime())
          cover_letter_path = os.path.join(APP_ROOT, "data/"+str(user.id)+"/coverletter/"+str(date))
          isExists=os.path.exists(cover_letter_path)
          if not isExists:
            os.makedirs(cover_letter_path) 
          with open(os.path.join(cover_letter_path, "templates_"+str(item["jobs"][0]['jobid'])+".tex"),'w',encoding='utf-8') as f:
            f.write(content)
          # pdflatex  -output-directory="./" -job-name="coverletter"  .\templates.tex.bk
          _r = subprocess.check_output(['powershell.exe',' pdflatex','-output-directory="'+cover_letter_path+'"',
                                  '-job-name="coverletter_'+str(item["jobs"][0]['jobid'])+'"','"'+os.path.join(cover_letter_path, 'templates_'+str(item["jobs"][0]['jobid'])+'.tex')+'"'],shell=False)
          os.remove(os.path.join(cover_letter_path, "coverletter_"+str(item["jobs"][0]['jobid'])+".aux"))
          os.remove(os.path.join(cover_letter_path, "coverletter_"+str(item["jobs"][0]['jobid'])+".log"))
          os.remove(os.path.join(cover_letter_path, "coverletter_"+str(item["jobs"][0]['jobid'])+".out"))
          with db.auto_commit():
            _cover_letter = coverletter.CoverLetter()
            _cover_letter.u_id = user.id
            _cover_letter.j_id = item["jobs"][0]['jobid']
            _cover_letter.cover_letter_data = str(_cover_letter_data)
            _cover_letter.cover_file_location_origin = os.path.join(cover_letter_path,'coverletter_'+str(item["jobs"][0]['jobid'])+'.pdf')
            _cover_letter.status = 0
            db.session.add(_cover_letter)


def sendtest(app):
  with app.app_context():
    from app.models.job import Job
    from app.rpa.outlook_send import sendmail
    from app.models.user import User

    jobs = Job.query.filter_by(status=1).all()
    for job in jobs:
      user=User.query.filter_by(id=job.u_id).first()
      usr_email=user.email
      usr_name=user.name
      job_pst=job.title
      sendmail(job.company_email,job.file_location,usr_email,usr_name,job_pst)


  return Success()

def scan_changeDataStatus(app):
  with app.app_context():
    from app.models.user import User
    from app.models.job import Job
    from app.models.base import db
    
    #select all job status to 5 (over date)
    jobs = Job.query.filter_by().all()
    print(jobs)
    for job in jobs:
      job.status = 5
      db.session.commit()
