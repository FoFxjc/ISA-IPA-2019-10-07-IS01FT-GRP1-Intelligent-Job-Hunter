from collections import OrderedDict

from flask import g

from app.libs.timeutil import timestamp_to_data
from app.models.course import Course
from app.models.adjustment import Adjustment
from app.models.appointment import Appointment
from app.viewmodels.appointment import AppointmentCollection



class CourseViewModel(object):
    def __init__(self, course):
        self.id = course['id']
        self.name = course['name']
        self.start_date = timestamp_to_data(course['start_date'])
        self.end_date = timestamp_to_data(course['end_date'])
        self.classes_num_limited = course['classes_num_limited']
        self.tch = {
            'id': course.teacher['id'],
            'name': course.teacher['name'],
            'email': course.teacher['email'],
            'gender': course.teacher['gender']
        }
        self.app_deadline = timestamp_to_data(course['app_deadline'])
        self.detail = course['detail']
        self.status = course['status']
        self.types = self.get_types(course['types'])
        self.tch_adjustments = self.get_tch_adjustments(course['tch_adjustments'])
        self.appointment_types = self.get_appointment_types(course['id'])

    def keys(self):
        return ['id', 'name', 'start_date', 'end_date','types',
                'classes_num_limited','app_deadline','tch','detail','status','tch_adjustments','appointment_types']

    def __getitem__(self, item):
        return getattr(self, item)

    def get_types(self,types_str):
        _types = []
        if types_str and types_str != "[]":
            types_str = types_str[1:-1]
            types = types_str.split(',')
            for _temp in types:
                _types.append(_temp.strip()[1:-1])
        return _types

    def get_tch_adjustments(self,tch_adjustment_str):
        adjustments = []
        if tch_adjustment_str and tch_adjustment_str != "[]":
            adjustment_str = tch_adjustment_str[1:-1]
            adjustments = adjustment_str.split(',')
            adjustments_list = Adjustment.query.filter(
                Adjustment.id.in_(adjustments)).all()
            return adjustments_list
        return []

    def get_appointment_types(self,course_id):
        appointments_types = {}
        appointments_types['waiting'] = Appointment.query.filter_by(course_id=course_id,status=1).count()
        appointments_types['approved'] = Appointment.query.filter_by(course_id=course_id,status=2).count()
        appointments_types['close'] = Appointment.query.filter_by(course_id=course_id,status=0).count()
        classes = 0
        apps_approved = Appointment.query.filter_by(course_id=course_id,status=2).all()
        for app_a in apps_approved:
            classes = classes + (app_a.recommend_speaking + app_a.recommend_writing+ app_a.recommend_listening + app_a.recommend_reading )/2
        appointments_types['approved_classes_num'] = classes
        return appointments_types


class CourseCollection(object):
    def __init__(self):
        self.data = []

    def fill(self, courses):
        self.data = [CourseViewModel(course) for course in courses]
