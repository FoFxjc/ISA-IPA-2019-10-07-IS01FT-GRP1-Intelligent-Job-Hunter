from collections import OrderedDict

from flask import g

from app.libs.timeutil import timestamp_to_data,timestamp_to_TZDATE,date_to_timestamp
from app.models.course import Course
from app.models.calendar import Calendar
from app.models.scheduler import Scheduler
from app.viewmodels.scheduler import SchedulerCollection
from app.libs.enums import get_module_color
import time


class CalendarViewModel_stu(object):
    def __init__(self, calendar):
        self.data = {}
        self.get_all_scheduler(calendar['id'])
        self.get_process(calendar['id'])

    def get_all_scheduler(self,cal_id):
        view_calendar = []
        view_scheduler = []
        categories_sql = Scheduler.query.filter_by(cal_id=cal_id).with_entities(
            Scheduler.category).distinct().all()
        categories = [category_sql.category for category_sql in categories_sql]
        _scheduler_id = 0
        _calendar_id = 0
        for category in categories:
            _calendar = {}
            _calendar['id'] = _calendar_id
            _calendar['name'] = category
            _calendar['bgColor'] = get_module_color(category)
            _calendar['borderColor'] = get_module_color(category)
            view_calendar.append(_calendar)
            schedulers = Scheduler.query.filter_by(cal_id=cal_id,category=category).all()
            for scheduler in schedulers:
                _scheduler = {}
                _scheduler['id'] = _scheduler_id
                _scheduler['calendarId'] = _calendar_id
                _scheduler['title'] = category
                _scheduler['category'] = 'time'
                _scheduler['start'] = timestamp_to_TZDATE(scheduler['start_date'])
                _scheduler['end'] = timestamp_to_TZDATE(scheduler['end_date'])
                _scheduler['isReadOnly'] = 'true'
                view_scheduler.append(_scheduler)
                _scheduler_id = _scheduler_id + 1
            _calendar_id = _calendar_id + 1
        self.data['calendarList'] = view_calendar
        self.data['scheduleList'] = view_scheduler

    def get_process(self,cal_id):
        calendarList = self.data['calendarList']
        for calendar in calendarList:
            category = calendar['name']
            _scheduler_total = Scheduler.query.filter_by(cal_id=cal_id,category=category).count()
            _scheduler_remain = Scheduler.query.filter(Scheduler.cal_id == cal_id,
                                                    Scheduler.category == category,
                                                    Scheduler.start_date >
                                                    int(time.time())).count()
            calendar['total_class'] = _scheduler_total
            calendar['remain_class'] = _scheduler_remain

class CalendarViewModel_tch(object):
    def __init__(self, calendars):
        self.data = {}
        self.get_all_scheduler(calendars)
        self.get_process(calendars)

    def get_all_scheduler(self,calendars):
        view_calendar = []
        view_scheduler = []
        _scheduler_id = 0
        _calendar_id = 0
        for calendar in calendars:
            _calendar = {}
            _calendar['id'] = _calendar_id
            _calendar['name'] = calendar.student.name
            _calendar['bgColor'] = calendar.student.color
            _calendar['borderColor'] = calendar.student.color
            view_calendar.append(_calendar)
            schedulers = Scheduler.query.filter_by(cal_id=calendar.id).all()
            for scheduler in schedulers:
                _scheduler = {}
                _scheduler['id'] = _scheduler_id
                _scheduler['calendarId'] = _calendar_id
                _scheduler['title'] = scheduler.category + "-" + scheduler.calendar.student.name
                _scheduler['detail'] = scheduler.category + "-" + scheduler.calendar.student.name
                _scheduler['category'] = 'time'
                _scheduler['start'] = timestamp_to_TZDATE(scheduler['start_date'])
                _scheduler['end'] = timestamp_to_TZDATE(scheduler['end_date'])
                _scheduler['isReadOnly'] = 'true'
                view_scheduler.append(_scheduler)
                _scheduler_id = _scheduler_id + 1
            _calendar_id = _calendar_id + 1
        self.data['calendarList'] = view_calendar
        self.data['scheduleList'] = view_scheduler

    def get_process(self,calendars):
        calendarList = self.data['calendarList']
        cal_ids = [calendar.id for calendar in calendars]
        for calendar in calendarList:
            category = calendar['name']
            _scheduler_total = Scheduler.query.filter(Scheduler.cal_id.in_(cal_ids),Scheduler.category == category).count()
            _scheduler_remain = Scheduler.query.filter(Scheduler.cal_id.in_(cal_ids),
                                                    Scheduler.category == category,
                                                    Scheduler.start_date >
                                                    int(time.time())).count()
            calendar['total_class'] = _scheduler_total
            calendar['remain_class'] = _scheduler_remain
            
