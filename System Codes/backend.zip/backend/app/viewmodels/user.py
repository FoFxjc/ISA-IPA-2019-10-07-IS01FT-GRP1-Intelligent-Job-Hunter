from app.libs.enums import roles
from app.models.user import User
from app.models.resume import Resume
from sqlalchemy import or_

class UserViewModel(object):
    def __init__(self, user):
        self.id = user['id']
        self.openid = user['openid']
        self.name = user['name']
        self.email = user['email']
        self.age = user['age']
        self.gender = user['gender']
        self.domain = 'user'
        self.uploadedresume = self.hasResume(user['id'])
        self.monitor_email_account = user['monitor_email_account']

    def hasResume(self,u_id):
        resume = Resume.query.filter_by(u_id=u_id).first()
        if resume:
            return 1
        else:
            return 0



    def keys(self):
        return ['id', 'name','age', 'email','gender','domain','uploadedresume','openid','monitor_email_account']

    def __getitem__(self, item):
        return getattr(self, item)


class UserCollection():
    def __init__(self):
        pass

    def fill(self, users):
        self.users = [UserViewModel(user) for user in users]