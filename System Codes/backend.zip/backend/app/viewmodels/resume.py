from collections import OrderedDict

from flask import g

from app.libs.timeutil import timestamp_to_data
from app.models.resume import Resume
import ast


class ResumeViewModel(object):
    def __init__(self, resume):
        self.id = resume['id']
        self.name = resume['name']
        self.phone = resume['phone']
        self.email = resume['email']
        self.resume_type = self.getResume_type(resume['resume_type'])
        self.education_experience = self.geteducation_experience(resume['education_experience'])
        self.project_experience = self.getproject_experience(resume['project_experience'])

    def keys(self):
        return ['id', 'name', 'phone', 'email','resume_type',
                'education_experience','project_experience']

    def __getitem__(self, item):
        return getattr(self, item)

    def getResume_type(self,resume_type):
        print(resume_type)
        if '[' not in resume_type:
            return resume_type
        else:
            return ast.literal_eval(resume_type)
    
    def geteducation_experience(self,education_experience):
        return ast.literal_eval(education_experience)

    def getproject_experience(self,project_experience):
        return ast.literal_eval(project_experience)


class ResumeModel(object):
    def __init__(self, resume):
        self.id = resume['id']
        self.name = resume['name']
        self.phone = resume['phone']
        self.email = resume['email']
        self.resume_type = resume['resume_type']
        self.education_experience = self.geteducation_experience(resume['education_experience'])
        self.project_experience = self.getproject_experience(resume['project_experience'])

    def keys(self):
        return ['id', 'name', 'phone', 'email','resume_type',
                'education_experience','project_experience']

    def __getitem__(self, item):
        return getattr(self, item)
    
    def geteducation_experience(self,education_experience):
        return ast.literal_eval(education_experience)

    def getproject_experience(self,project_experience):
        return ast.literal_eval(project_experience)
