from collections import OrderedDict

from flask import g

from app.libs.timeutil import timestamp_to_data
from app.models.resume import Resume
from app.models.coverletter import CoverLetter
from app.models.job import Job
import ast


class CoverLetterViewModel(object):
    def __init__(self, coverletter):
        self.id = coverletter['id']
        self.user = coverletter.user.id
        self.job = coverletter.job.id
        self.data = self.getdata(coverletter.cover_letter_data)

    def keys(self):
        return ['id', 'user', 'job','data']

    def __getitem__(self, item):
        return getattr(self, item)
    
    def getdata(self,coverletterdata):
        return ast.literal_eval(coverletterdata)


class CoverLetterCollection():
    def __init__(self):
        self.data = []

    def fill(self, coverletters):
        self.data = [CoverLetterViewModel(coverletter) for coverletter in coverletters]