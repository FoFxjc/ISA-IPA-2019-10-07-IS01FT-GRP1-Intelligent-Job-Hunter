from collections import OrderedDict

from flask import g

from app.libs.timeutil import timestamp_to_data
from app.models.course import Course
from app.models.student import Student
from app.models.adjustment import Adjustment




class AppointmentViewModel(object):
    def __init__(self, appointment):
        self.id = appointment['id']
        self.course = {}
        self.course['id'] = appointment.course['id']
        self.course['name'] = appointment.course['name']
        self.course['start_date'] = timestamp_to_data(appointment.course['start_date'])
        self.course['end_date'] = timestamp_to_data(appointment.course['end_date'])
        self.course['end_date'] = appointment.course['classes_num_limited']
        self.course['tch'] = {
            'id': appointment.course.teacher['id'],
            'name': appointment.course.teacher['name'],
            'email': appointment.course.teacher['email'],
            'gender': appointment.course.teacher['gender']
        }
        self.course['app_deadline'] = timestamp_to_data(appointment.course['app_deadline'])
        self.course['types'] = self.get_types(appointment.course['types'])
        self.course['status'] = appointment.course['status']
        self.teacher = {
            'id': appointment.course.teacher['id'],
            'name': appointment.course.teacher['name'],
        }
        self.type = appointment['type']
        self.point_speaking = appointment['point_speaking']
        self.point_reading = appointment['point_reading']
        self.point_writing = appointment['point_writing']
        self.point_listening = appointment['point_listening']
        self.point_total = appointment['point_total']
        self.target_speaking = appointment['target_speaking']
        self.target_reading = appointment['target_reading']
        self.target_writing = appointment['target_writing']
        self.target_listening = appointment['target_listening']
        self.target_total = appointment['target_total']
        self.recommend_speaking = appointment['recommend_speaking']
        self.recommend_reading = appointment['recommend_reading']
        self.recommend_writing = appointment['recommend_writing']
        self.recommend_listening = appointment['recommend_listening']
        self.stu_adjustments = self.get_stu_adjustments(appointment['stu_adjustments'])
        self.student = {
            'id': appointment.student['id'],
            'name': appointment.student['name'],
        }
        self.status = appointment['status']

    def keys(self):
        return ['id', 'course', 'teacher', 'student',
                'type',
                'point_speaking','point_reading','point_writing','point_listening','point_total',
                'target_speaking','target_reading','target_writing','target_listening','target_total',
                'recommend_speaking','recommend_reading','recommend_writing','recommend_listening',
                'stu_adjustments','status']

    def __getitem__(self, item):
        return getattr(self, item)

    def get_stu_adjustments(self, stu_adjustment_str):
        if stu_adjustment_str and stu_adjustment_str != "[]":
            adjustment_str = stu_adjustment_str[1:-1]
            adjustments = adjustment_str.split(',')
            adjustments_list = Adjustment.query.filter(
                Adjustment.id.in_(adjustments)).all()
            return adjustments_list
        else:
            return []

    def get_types(self,types_str):
        _types = []
        if types_str and types_str != "[]":
            types_str = types_str[1:-1]
            types = types_str.split(',')
            for _temp in types:
                _types.append(_temp.strip()[1:-1])
        return _types

class AppointmentCollection(object):
    def __init__(self):
        self.data = []

    def fill(self, appointments):
        self.data= [AppointmentViewModel(appointment) for appointment in appointments]
