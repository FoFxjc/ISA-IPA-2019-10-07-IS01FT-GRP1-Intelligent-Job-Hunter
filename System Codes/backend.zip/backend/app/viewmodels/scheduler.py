from collections import OrderedDict

from flask import g

from app.libs.timeutil import timestamp_to_data,timestamp_to_TZDATE
from app.models.course import Course
from app.models.calendar import Calendar
from app.models.scheduler import Scheduler



class SchedulerViewModel(object):
    def __init__(self, scheduler):
        self.id = scheduler['id']
        self.category = scheduler['category']
        self.start_date = timestamp_to_TZDATE(scheduler['start_date'])
        self.end_date = timestamp_to_TZDATE(scheduler['end_date'])
        self.detail = scheduler['detail']
        self.status = scheduler['status']

    def keys(self):
        return ['id', 'category', 'detail', 'end_date',
                'start_date','status']

    def __getitem__(self, item):
        return getattr(self, item)


class SchedulerCollection(object):
    def __init__(self):
        self.data = []

    def fill(self, schedulers):
        self.data = [SchedulerViewModel(scheduler) for scheduler in schedulers]
