#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
@File    :   __init__.py
@Time    :   2019/03/12 10:52:07
@Author  :   Jiachen Xu
@Desc    :   None
'''
from .app import Flask
from flask_mail import Mail, Message
from flask_cors import CORS
from flask_apscheduler import APScheduler
from app.libs.flask_wechatpy import Wechat
from app.libs.tasks import scan_startSend,collecttest,sendtest,scan_changeDataStatus
import pytz
from wechatpy import WeChatClient
from flask import current_app
from app.config.wechat import WECHAT_APPID,WECHAT_SECRET
# here put the import lib
def register_blueprints(app):
  from app.api.v1 import create_blueprint_v1
  app.register_blueprint(create_blueprint_v1(), url_prefix='/api/v1')

def register_plugin(app):
  from app.models.base import db
  db.init_app(app)
  with app.app_context():
    db.create_all()

def register_wechat(app):
  wechat = Wechat(app)
  # client = WeChatClient(WECHAT_APPID, WECHAT_SECRET)
  # client.menu.create({
  #   "button": [
  #     {
  #       "type": "click",
  #       "name": "Website",
  #       "key": "V1001_TODAY_WEBSITE"
  #     },
  #     {
  #       "type": "click",
  #       "name": "About",
  #       "key": "V1001_TODAY_ABOUT"
  #     },
  #   ],
  # })


def register_scheduler(app):
  scheduler=APScheduler()
  scheduler.init_app(app)
  scheduler.start()
  timezone = pytz.timezone('Asia/Shanghai')
  
  scheduler.add_job(func=collecttest, trigger='cron',args=[app],hour='16', minute='40', second='00',id='collecttest',timezone=timezone)
  scheduler.add_job(func=scan_startSend, trigger='cron',args=[app],hour='17', minute='49', second='00',id='scan_startSend',timezone=timezone)


def create_app():
  app = Flask(__name__)
  cors = CORS(app, resources={r"/": {"origins": "*"}})
  app.config.from_object('app.config.setting')
  app.config.from_object('app.config.secure')
  app.config.from_object('app.config.scheduler')
  app.config.from_object('app.config.wechat')
  register_blueprints(app)
  register_plugin(app)
  register_scheduler(app)
  register_wechat(app)
  return app

def create_db_app():
  app = Flask(__name__)
  app.config.from_object('app.config.setting')
  app.config.from_object('app.config.secure')
  register_plugin(app)
  return app

