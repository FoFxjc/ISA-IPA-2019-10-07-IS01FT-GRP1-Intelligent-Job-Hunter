import time
from datetime import timezone, timedelta
import datetime
from dateutil.relativedelta import relativedelta

def date_to_timestamp(date, format_string="%Y.%m.%d"):
    time_array = time.strptime(date, format_string)
    time_stamp = int(time.mktime(time_array))
    return time_stamp

def timestamp_to_data(timestamp,format_string="%Y.%m.%d"):
    timestruct = time.localtime(timestamp)
    return time.strftime(format_string, timestruct)



def timestamp_to_TZDATE(timestamp,format_string="%Y--%m--%d %H:%M:%S"):
    data = datetime.datetime.utcfromtimestamp(timestamp)
    utc_tz = timezone(timedelta(hours=0))
    data = data.replace(tzinfo=utc_tz)
    datas = data.astimezone(timezone(timedelta(hours=8)))   # 直接转带时区的时间
    return (datas.strftime("%Y-%m-%dT%H:%M:%S%Z")).replace('UTC','')
    
time = 1577721600
print(timestamp_to_TZDATE(time))