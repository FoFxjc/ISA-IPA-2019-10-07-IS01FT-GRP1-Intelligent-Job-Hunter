<template>
  <div class="detail-container">
    <el-row :gutter="20">
      <el-col :span="4">
        <el-row>
          <box-card :userinfo="userinfo"/>
        </el-row>
      </el-col>
      <el-col :span="20">
        <el-row>
          <detail-content/>
        </el-row>
      </el-col>
    </el-row>
  </div>
</template>
<script>
import { getInfo } from '@/api/user'
import DetailContent from './components/Content'
import BoxCard from './components/BoxCard'
export default {
  components: {
    DetailContent,
    BoxCard
  },
  data() {
    return {
      userinfo: {},
      commonColor: '',
      loaddata: {},
      lifecycle: {},
      usersstatus: {},
      id: '',
      history: []
    }
  },
  watch: {
    '$route': function(to, from) {
      this.getList(this.$route.params.id)
    }
  },
  created() {
    this.initaldata()
  },
  methods: {
    initaldata() {
      getInfo().then(response => {
        this.userinfo = response
        if (this.userinfo.uploadedresume !== 1) {
          this.$notify({
            title: 'Resume',
            message: 'Please Upload your resume.',
            type: 'warning',
            duration: 1000
          })
        }
        if (this.userinfo.monitor_email_account === '') {
          this.$notify({
            title: 'Monitor Email',
            message: 'Please Upload your email for Job Collection.',
            type: 'warning',
            duration: 1000
          })
        }
      })
    },
    updatePage() {
      // 更新状态 组件
      for (const lifecycle of this.$store.getters.lifecycle) {
        if (this.loaddata.status === lifecycle.status) {
          this.lifecycle = lifecycle
        }
      }
      this.usersstatus = this.loaddata.usersstatus
      this.commonColor = this.lifecycle.iconColor
      this.id = this.loaddata.id
    }
  }
}
</script>
<style lang="scss" scoped>
.detail-container {
  padding: 18px;
  background-color: rgb(240, 242, 245);
}
</style>
