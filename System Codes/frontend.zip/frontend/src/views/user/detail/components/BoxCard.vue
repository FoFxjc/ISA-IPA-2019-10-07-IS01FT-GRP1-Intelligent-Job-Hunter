<template>
  <div>
    <el-card
      class="box-card-component"
      style="margin-left:8px;"
    >
      <div
        slot="header"
        class="box-card-header"
      >
        <div class="button">
          <div
            :style="{background: titlebg} "
            class="card-panel-icon-wrapper"
          >
            <svg-icon
              :icon-class="userinfo.gender"
              class-name="card-panel-icon"
            />
            <div class="card-panel-description">
              <div class="card-panel-text">{{ userinfo.name }}</div>
            </div>
          </div>
        </div>
      </div>
      <div style="position:relative;">
        <div class="info-item">
          <el-row :gutter="10">
            <el-col :span="10">
              <span class="label">ID</span>
            </el-col>
            <el-col :span="12">
              <el-tag>{{ userinfo.id }}</el-tag>
            </el-col>
          </el-row>
        </div>
        <div class="info-item">
          <el-row :gutter="10">
            <el-col :span="10">
              <span class="label">Gender</span>
            </el-col>
            <el-col :span="12">
              <el-tag >{{ userinfo.gender }}</el-tag>
            </el-col>
          </el-row>
        </div>
        <div class="info-item">
          <el-row :gutter="10">
            <el-col :span="10">
              <span class="label">Email</span>
            </el-col>
            <el-col :span="12">
              <el-tag >
                <a :href="'mailto:'+userinfo.email" style="color:blue;">
                  <i class="el-icon-message"/>
                </a>
              </el-tag>
            </el-col>
          </el-row>
        </div>
        <div class="info-item">
          <el-row :gutter="10">
            <el-col :span="10">
              <span class="label">Monitor Email</span>
            </el-col>
            <el-col :span="12">
              <el-tag v-if="userinfo.monitor_email_account" type="success">
                Uploaded
              </el-tag>
              <el-tag v-else type="warning" style="cursor:pointer;">
                Not Ready
              </el-tag>
            </el-col>
          </el-row>
        </div>
        <div class="info-item">
          <el-row :gutter="10">
            <el-col :span="10">
              <span class="label">Resume</span>
            </el-col>
            <el-col :span="12">
              <el-tag v-if="userinfo.uploadedresume == 1" type="success">
                Uploaded
              </el-tag>
              <el-tag v-else type="warning" style="cursor:pointer;">
                Not Ready
              </el-tag>
            </el-col>
          </el-row>
        </div>
      </div>
    </el-card>
  </div>
</template>

<script>
export default {
  props: {
    userinfo: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
    }
  },
  computed: {
    titlebg: function() {
      if (this.userinfo.gender === 'male') {
        return 'lightblue'
      } else if (this.userinfo.gender === 'female') {
        return 'lightpink'
      }
    }
  },
  methods: {

  }
}
</script>

<style rel="stylesheet/scss" lang="scss" >
.box-card-component {
  .el-card__header {
    padding: 0px !important;
  }
}
.box-card-component /deep/ .el-card__body {
  padding-bottom: 2px;
}
</style>
<style lang="scss" scoped>
.box-card-component {
  .box-card-header {
    position: relative;
    height: 140px;
    .button {
      width: 100%;
      height: 100%;
      border: none;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.4);
      background: -webkit-linear-gradient(top, #fff, #d5dbe1);
      background: -moz-linear-gradient(top, #fff, #d5dbe1);
      background: -ms-linear-gradient(top, #fff, #d5dbe1);
      background: -o-linear-gradient(top, #fff, #d5dbe1);
      -webkit-transition: all 0.13s ease-out;
      -moz-transition: all 0.13s ease-out;
      -o-transition: all 0.13s ease-out;
      transition: all 0.13s ease-out;
      .card-panel-icon-wrapper {
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        text-align: center;
        color: #fff;
        background: -webkit-linear-gradient(top, #fff, #d5dbe1);
        background: -moz-linear-gradient(top, #fff, #d5dbe1);
        background: -ms-linear-gradient(top, #fff, #d5dbe1);
        background: -o-linear-gradient(top, #fff, #d5dbe1);
        .card-panel-icon {
          font-size: 80px;
        }
      }
      .card-panel-description {
        margin-top: 10px;
        .card-panel-text {
          font-weight: bold;
        }
      }
    }
  }
}
.info-item {
  margin-bottom: 10px;
  .label {
    font-size: 13px;
    font-weight: bold;
    line-height: 30px;
  }
}
</style>
