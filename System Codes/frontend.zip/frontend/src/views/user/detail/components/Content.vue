<template>
  <el-card class="box-card">
    <div slot="header" :style="{background: titlebg}" class="clearfix header"/>
    <el-tabs tab-position="right" style="min-height: 180px;">
      <el-tab-pane label="Profile">
        <div class="applictioninfo">
          <h2 class="step-title">Personal Info</h2>
          <div style="margin-top:10px;">
            <el-form ref="form" :model="form" :rules="rules" label-width="130px" >
              <el-row>
                <el-col :span="6">
                  <el-form-item label="ID" prop="id">
                    <el-input v-model="form.id" class="article-input" style="margin-left:30px;" disabled/>
                  </el-form-item>
                </el-col>
                <el-col :span="12">
                  <el-form-item label="OpenID" prop="id">
                    <el-input v-model="form.openid" class="article-input" style="margin-left:30px;" disabled/>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row>
                <el-col :span="6">
                  <el-form-item label="Name" prop="name">
                    <el-input v-model="form.name" :disabled="!enable_for_edit" class="article-input" style="margin-left:30px;"/>
                  </el-form-item>
                </el-col>
                <el-col :span="6">
                  <el-form-item label="Gender" prop="gender">
                    <el-select v-model="form.gender" :disabled="!enable_for_edit" placeholder="Gender" style="margin-left:30px;">
                      <el-option label="Male" value="male"/>
                      <el-option label="Female" value="female"/>
                    </el-select>
                  </el-form-item>
                </el-col>

              </el-row>
              <el-row>
                <el-col :span="6">
                  <el-form-item label="Age" prop="age">
                    <el-input-number v-model="form.age" :disabled="!enable_for_edit" style="margin-left:30px;"/>
                  </el-form-item>
                </el-col>
                <el-col :span="16">
                  <el-form-item label="Email" prop="email">
                    <el-input v-model="form.email" :disabled="!enable_for_edit" class="article-input" style="margin-left:30px;"/>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-form-item>
                <el-row>
                  <el-col :span="4" :offset="20">
                    <el-button v-show="!editable" type="primary" icon="el-icon-edit" circle @click="handleProfileEdit"/>
                    <el-button v-show="editable" type="primary" icon="el-icon-upload" circle @click="handleProfileUpdate"/>
                    <el-button v-show="editable" icon="el-icon-close" circle @click="handleEditCancel"/>
                  </el-col>
                </el-row>
              </el-form-item>
            </el-form>

          </div>
        </div>
      </el-tab-pane>
      <el-tab-pane label="ChangePwd">
        <div class="applictioninfo">
          <h2 class="step-title">Change Password</h2>
          <div style="margin-top:10px;">
            <el-form ref="changepwdform" :model="changepwdform" :rules="rulespwd" label-width="200px">
              <el-row>
                <el-col :span="10">
                  <el-form-item :error="errors.oldpwd" label="Original Password" prop="oldpwd">
                    <el-input v-model="changepwdform.oldpwd" type="password"/>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row>
                <el-col :span="10">
                  <el-form-item label="New Password" prop="newpwd" status-icon >
                    <el-input v-model="changepwdform.newpwd" type="password" autocomplete="off" show-password/>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row>
                <el-col :span="10">
                  <el-form-item label="Confirm New Password" prop="checknewpwd" status-icon>
                    <el-input v-model="changepwdform.checknewpwd" type="password" autocomplete="off" show-password/>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-form-item>
                <el-row>
                  <el-col :span="6" :offset="18">
                    <el-button type="primary" icon="el-icon-upload" @click="handlePwdUpdate">Confirm</el-button>
                    <el-button @click="resetForm('changepwdform')">Reset</el-button>
                  </el-col>
                </el-row>
              </el-form-item>
            </el-form>
          </div>
        </div>
      </el-tab-pane>
      <el-tab-pane label="Monitor Email">
        <div class="applictioninfo">
          <h2 class="step-title">Upload Monitor Email</h2>
          <div style="margin-top:10px;">
            <el-form ref="uploademailform" :model="uploademailform" :rules="rulesemail" label-width="200px">
              <el-row>
                <el-col :span="10">
                  <el-form-item label="Email Account" prop="account">
                    <el-input :disabled="!enable_for_edit_m" v-model="uploademailform.account"/>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row v-show="enable_for_edit_m">
                <el-col :span="10" >
                  <el-form-item label="Email Password" prop="pwd" status-icon>
                    <el-input v-model="uploademailform.pwd" type="password" autocomplete="off" show-password/>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-row v-show="enable_for_edit_m">
                <el-col :span="10">
                  <el-form-item label="Confirm Email Password" prop="checkpwd" status-icon>
                    <el-input v-model="uploademailform.checkpwd" type="password" autocomplete="off" show-password/>
                  </el-form-item>
                </el-col>
              </el-row>
              <el-form-item>
                <el-row>
                  <el-col :span="6" :offset="20">
                    <el-button v-show="!editable_m" type="primary" icon="el-icon-edit" circle @click="handleMemailEdit"/>
                    <el-button v-show="editable_m" type="primary" icon="el-icon-upload" circle @click="handleMemailUpdate"/>
                    <el-button v-show="editable_m" icon="el-icon-close" circle @click="handleEditMemailCancel"/>
                  </el-col>
                </el-row>
              </el-form-item>
            </el-form>
          </div>
        </div>
      </el-tab-pane>
      <el-tab-pane
        v-loading="loading"
        ref="uploadResume"
        element-loading-text="Uploading and Analyzing your resume"
        element-loading-spinner="el-icon-loading"
        element-loading-background="rgba(0, 0, 0, 0.8)"
        label="UploadResume">
        <div class="applictioninfo">
          <h2 class="step-title">Upload Resume</h2>
          <div v-if="userinfo.uploadedresume == 0" style="margin:20px 20px;">
            <el-upload
              :http-request="beforeUpload"
              action=""
              class="upload-demo"
              drag
              accept=".pdf">
              <i class="el-icon-upload"/>
              <div class="el-upload__text">Please drag the document(only PDF) here, or<em> Click</em></div>
            </el-upload>
          </div>
          <div v-else style="width:400px;">
            <el-progress :percentage="100" :format="format"/>
            <el-tag>
              You have already uploaded your resume.
            </el-tag>
          </div>
        </div>
      </el-tab-pane>
    </el-tabs>
  </el-card>
</template>
<script>
import { getInfo, updateUserInfo, updatePassword, uploadMonitorEmail } from '@/api/user'
import { deepClone } from '@/utils/index'
import { validatePassword } from '@/utils/validate'
import Tinymce from '@/components/Tinymce'
import { mapGetters } from 'vuex'
import LogPanel from './LogPanel'
import axios from 'axios'
export default {
  name: 'DetailContent',
  components: {
    Tinymce,
    LogPanel
  },
  data() {
    var validateoldPass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('Please enter old password'))
      } else {
        callback()
      }
    }
    var validatePass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('Please enter new password'))
      } else if (!validatePassword(value)) {
        callback(new Error('Password can only contain 6-20 digits, upper and lower case English characters'))
      } else {
        if (this.changepwdform.checknewpwd !== '') {
          this.$refs.changepwdform.validateField('checknewpwd')
        }
        callback()
      }
    }
    var validatePass2 = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('Please enter new password again'))
      } else if (value !== this.changepwdform.newpwd) {
        callback(new Error('The two passwords do not match!'))
      } else {
        callback()
      }
    }
    var validatePass_m = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('Please enter password of the email above'))
      } else {
        if (this.uploademailform.checknewpwd !== '') {
          this.$refs.uploademailform.validateField('checkpwd')
        }
        callback()
      }
    }
    var validatePass2_m = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('Please enter password of the email above again'))
      } else if (value !== this.uploademailform.checkpwd) {
        callback(new Error('The two passwords do not match!'))
      } else {
        callback()
      }
    }
    return {
      doUpload: '/api/v1/resume/upload',
      enable_for_edit: false,
      enable_for_edit_m: false,
      activeNames: ['1', '2'],
      resultedit: false,
      editable: false,
      editable_m: false,
      loading: false,
      form: {},
      userinfo: {},
      changepwdform: {
        oldpwd: '',
        newpwd: '',
        checknewpwd: ''
      },
      uploademailform: {
        account: '',
        pwd: '',
        checkpwd: ''
      },
      rules: {
        id: [
          { required: true, message: '', trigger: 'blur' }
        ],
        name: [
          { required: true, message: 'Pleace enter your name', trigger: 'blur' }
        ],
        gender: [
          { required: true, message: 'Pleace choose your gender', trigger: 'change' }
        ],
        email: [
          { required: true, message: 'Pleace enter your email address', trigger: 'blur' }
        ],
        color: [
          { required: true, message: 'Pleace select a color for your scheduler', trigger: 'blur' }
        ]
      },
      rulespwd: {
        oldpwd: [{ validator: validateoldPass, trigger: 'blur' }],
        newpwd: [
          { validator: validatePass, trigger: 'blur' }
        ],
        checknewpwd: [
          { validator: validatePass2, trigger: 'blur' }
        ]
      },
      rulesemail: {
        account: [{ required: true, message: 'Pleace enter your email which need to be monitored', trigger: 'blur' }],
        pwd: [
          { validator: validatePass_m, trigger: 'blur' }
        ],
        checkpwd: [
          { validator: validatePass2_m, trigger: 'blur' }
        ]
      },
      errors: {
        oldpwd: ''
      }
    }
  },
  computed: {
    ...mapGetters([
      'roles',
      'token'
    ]),
    titlebg: function() {
      if (this.userinfo.gender === 'male') {
        return 'lightblue'
      } else if (this.userinfo.gender === 'female') {
        return 'lightpink'
      }
    },
    headers: function() {
      return {
        'Authorization': {
          username: this.token
        }
      }
    }
  },
  created() {
    this.initaldata()
  },
  methods: {
    beforeUpload(file) {
      const param = new FormData()
      param.append('file', file.file)

      const config = {
        auth: {
          username: this.token
        },
        headers: { 'Content-Type': 'multipart/form-data' }
      }
      this.loading = true
      const _this = this
      axios.post('http://f1401923.ngrok.io/api/v1/resume/upload', param, config).then(res => {
        if (res.data.error_code === 0) {
          _this.$message({
            type: 'success',
            message: 'Upload Resume Successfully'
          })
          _this.loading = false
          const { fullPath } = _this.$route
          _this.$nextTick(() => {
            _this.$router.replace({
              path: '/redirect' + fullPath
            })
          })
        }
      })
      return false
    },
    initaldata() {
      getInfo().then(response => {
        this.userinfo = response
        this.form = deepClone(this.userinfo)
        this.userinfo_memail = {
          account: this.userinfo.monitor_email_account,
          pwd: '',
          checkpwd: ''

        }
        this.uploademailform = deepClone(this.userinfo_memail)
      })
    },
    resetForm(formName) {
      this.$refs[formName].resetFields()
    },
    handlePwdUpdate() {
      this.$refs['changepwdform'].validate((valid) => {
        this.errors.oldpwd = ''
        if (valid) {
          this.$confirm('Are you sure to change the password ?', 'Warning', {
            confirmButtonText: 'Confirm',
            cancelButtonText: 'Cancel',
            type: 'warning'
          }).then(() => {
            const updatepwdinfo = { 'oldpwd': this.changepwdform.oldpwd, 'newpwd': this.changepwdform.newpwd }
            updatePassword(updatepwdinfo).then(response => {
              if (response.error_code === 0) {
                this.$message({
                  type: 'success',
                  message: response.msg
                })
                this.$store.dispatch('LogOut').then(() => {
                  location.reload()
                })
              } else {
                this.$message({
                  type: 'error',
                  message: response.msg
                })
                this.errors.oldpwd = response.msg
              }
            }).catch(err => {
              console.log(err)
            })
          }).catch(() => {
            this.$message({
              type: 'info',
              message: 'Cancel to change the password'
            })
          })
        } else {
          this.$message({
            type: 'error',
            message: 'Something Wrong. Please check your input'
          })
        }
      })
    },
    handleProfileEdit: function() {
      this.enable_for_edit = true
      this.editable = true
    },
    handleMemailEdit: function() {
      this.enable_for_edit_m = true
      this.editable_m = true
    },
    handleProfileUpdate: function() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          this.$prompt('Plean enter your password', 'Alert', {
            confirmButtonText: 'Confirm',
            cancelButtonText: 'Cancel',
            inputPattern: /[A-Za-z0-9]{6,20}/,
            inputType: 'password',
            showClose: false,
            inputErrorMessage: 'Error Password Format',
            beforeClose: (action, instance, done) => {
              if (action === 'confirm') {
                instance.confirmButtonLoading = true
                instance.confirmButtonText = 'Updating...'
                const updateinfo = deepClone(this.form)
                updateinfo.password = instance.inputValue
                updateUserInfo(updateinfo).then(response => {
                  if (response.error_code === 0) {
                    this.$message({
                      type: 'success',
                      message: response.msg
                    })
                    const { fullPath } = this.$route
                    this.$nextTick(() => {
                      this.$router.replace({
                        path: '/redirect' + fullPath
                      })
                    })
                    instance.confirmButtonLoading = false
                    done()
                  } else {
                    instance.confirmButtonLoading = false
                    done()
                  }
                }).catch(err => {
                  console.log(err)
                })
                  .catch(() => {
                    this.$message({
                      type: 'info',
                      message: 'Cancel Submission'
                    })
                  })
              } else {
                instance.confirmButtonLoading = false
                done()
              }
            }
          })
        }
      })
      this.enable_for_edit = true
      this.editable = true
    },
    handleMemailUpdate: function() {
      this.$refs.uploademailform.validate((valid) => {
        if (valid) {
          this.$prompt('Plean enter your password', 'Alert', {
            confirmButtonText: 'Confirm',
            cancelButtonText: 'Cancel',
            inputPattern: /[A-Za-z0-9]{6,20}/,
            inputType: 'password',
            showClose: false,
            inputErrorMessage: 'Error Password Format',
            beforeClose: (action, instance, done) => {
              if (action === 'confirm') {
                instance.confirmButtonLoading = true
                instance.confirmButtonText = 'Updating...'
                const updateinfo = {}
                updateinfo.monitor_email_account = this.uploademailform.account
                updateinfo.monitor_email_password = this.uploademailform.pwd
                updateinfo.password = instance.inputValue
                uploadMonitorEmail(updateinfo).then(response => {
                  if (response.error_code === 0) {
                    this.$message({
                      type: 'success',
                      message: response.msg
                    })
                    const { fullPath } = this.$route
                    this.$nextTick(() => {
                      this.$router.replace({
                        path: '/redirect' + fullPath
                      })
                    })
                    instance.confirmButtonLoading = false
                    done()
                  } else {
                    instance.confirmButtonLoading = false
                    done()
                  }
                }).catch(err => {
                  console.log(err)
                })
                  .catch(() => {
                    this.$message({
                      type: 'info',
                      message: 'Cancel Submission'
                    })
                  })
              } else {
                instance.confirmButtonLoading = false
                done()
              }
            }
          })
        }
      })
      this.enable_for_edit_m = true
      this.editable_m = true
    },
    handleEditCancel: function() {
      this.enable_for_edit = false
      this.editable = false
      this.form = deepClone(this.userinfo)
    },
    handleEditMemailCancel: function() {
      this.enable_for_edit_m = false
      this.editable_m = false
      this.form = deepClone(this.userinfo_memail)
    }
  }
}
</script>
<style lang="scss" scoped>
.box-card /deep/ .el-card__header {
  // background: #36a3f7;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.4);
  padding: 0px;
  height: 35px;
}
.box-card /deep/ .el-card__body {
  padding: 0;
  padding-top: 5px;
  padding-left: 20px;
}
.collapse-panel /deep/ .el-collapse-item__wrap {
  background-color: transparent;
}
.collapse-panel /deep/ .el-collapse-item__header {
  background-color: transparent;
}
.box-card {
  background: rgba($color: #ffffff, $alpha: 0.8);
  .header {
    text-align: center;
    height: 100%;
    .header-title {
      vertical-align: middle;
      height: 100%;
      .title-text {
        padding: 7.5px 0;
        font-weight: bold;
        font-size: 20px;
        color: #ffffff;
      }
    }
  }
}
.applictioninfo {
  label {
    font-size: 14px;
  }
  .el-row {
    margin-top: 10px;
  }
}
.el-tabs__item .alert{
  background: #E6A23C
}
</style>
