<template>
  <div class="page-container">
    <el-row :gutter="5">
      <el-col :span="12">
        <el-card class="box-card tabs-card" shadow="always" style="min-height:500px;">
          <div slot="header" class="clearfix head-title">
            <div class="head-text" style="font-size:20px;margin-top:5px;">
              Resume
            </div>
            <div
              class="action-wrapper"
            >
              <el-tooltip class="item" effect="dark" content="Update" placement="top-start">
                <operation-button action="doschedule" style="margin-left:5px;" @handleOpertionButtonClick="handleOpertionButtonClick"/>
              </el-tooltip>
            </div>
          </div>
          <el-form ref="form" :model="resume_form" :rules="rules" label-position="top" label-width="180px" style="margin: 5px 5px;">
            <el-tabs tab-position="left" style="padding:0px;">
              <el-tab-pane label="Basic Info" style="min-height:500px;">

                <el-row>
                  <el-col :span="16">
                    <el-form-item label="Name" prop="name">
                      <el-input v-model="resume_form.name" class="article-input" placeholder="Name"/>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :span="16">
                    <el-form-item label="Phone" prop="phone">
                      <el-input v-model="resume_form.phone" class="article-input" placeholder="Phone"/>
                    </el-form-item>
                  </el-col>
                </el-row>
                <el-row>
                  <el-col :span="16">
                    <el-form-item label="Email" prop="email">
                      <el-input v-model="resume_form.email" class="article-input" placeholder="Email"/>
                    </el-form-item>
                  </el-col>
                </el-row>

              </el-tab-pane>
              <el-tab-pane label="Eduction" style="min-height:500px;">
                <el-collapse v-model="activeNames" accordion @change="handleChange">
                  <el-collapse-item v-for="(item,index) in resume_form.education_experience" :key="index" :name="index" :title="'Edication '+(index+1)" >
                    <el-row>
                      <el-col :span="16">
                        <el-form-item label="School" prop="id">
                          <el-input v-model="item.school" class="article-input" placeholder="School"/>
                        </el-form-item>
                      </el-col>
                    </el-row>
                    <el-row>
                      <el-col :span="16">
                        <el-form-item
                          :prop="'education_experience.' + index + '.date'"
                          :rules="[{ required: true, message: 'Please Enter date of this education experience', trigger: 'blur' },
                                   {pattern: /\d{4}/, message: 'Please Enter valid date of this education experience,e.g 2018-2019'}]"
                          label="Date">
                          <el-input v-model="item.date" class="article-input" placeholder="Date"/>
                        </el-form-item>
                      </el-col>
                    </el-row>
                  </el-collapse-item>
                </el-collapse>
              </el-tab-pane>
              <el-tab-pane label="Project" style="min-height:500px;">
                <el-collapse v-model="activeNames_p" accordion @change="handleChange">
                  <el-collapse-item v-for="(item,index) in resume_form.project_experience" :key="index" :name="index" :title="'Project '+(index+1)" >
                    <el-row>
                      <el-col :span="16">
                        <el-form-item label="Company Name" prop="id">
                          <el-input v-model="item.company" class="article-input" placeholder="Name"/>
                        </el-form-item>
                      </el-col>
                    </el-row>
                    <el-row>
                      <el-col :span="16">
                        <el-form-item label="Date" prop="id">
                          <el-input v-model="item.date" class="article-input" placeholder="Name"/>
                        </el-form-item>
                      </el-col>
                    </el-row>
                    <el-form-item label="Project Summary" prop="tch_id">
                      <el-input
                        :autosize="{ minRows: 6, maxRows: 10}"
                        v-model="item.summary"
                        type="textarea"
                        placeholder=""/>
                    </el-form-item>
                  </el-collapse-item>
                </el-collapse>
              </el-tab-pane>
              <el-tab-pane label="Resume Type" style="min-height:500px;" prop="resume_type">
                <el-checkbox-group v-model="resume_form.resume_type">
                  <el-checkbox label="AI"/>
                  <el-checkbox label="Software Engineer"/>
                  <el-checkbox label="UX"/>
                </el-checkbox-group>
              </el-tab-pane>
            </el-tabs>
          </el-form>
        </el-card>
      </el-col>
      <el-col :span="12">
        <el-card class="box-card pdf-preview" shadow="hover" style="min-height:700px;">
          <div slot="header" class="clearfix head-title">
            <div class="head-text" style="font-size:20px;margin-top:5px;height:30px;">
              Original Resume
            </div>
          </div>
          <iframe
            v-if="resume_loaded"
            id="previewPdf"
            :src="pdfurl"/>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>
<script>
import { getInfo } from '@/api/user'
import OperationButton from './components/OperationButton'
import BoxCard from './components/BoxCard'
import { deepClone } from '@/utils/index'
import { getAppointmentBySidCid } from '@/api/appointment'
import { getResumeData, uploadResumeData } from '@/api/resume'
export default {
  name: 'DashboardAdmin',
  components: {
    BoxCard,
    OperationButton
  },
  data() {
    const validateEducationDate = (rule, value, callback) => {
      console.log(value)
      if (value === '') {
        callback(new Error('Please Enter date of this education experience'))
      } else {
        const regex = /\d{4}/
        if (value.search(regex) === -1) {
          callback(new Error('Please Enter valid date of this education experience,e.g 2018-2019'))
        } else {
          callback()
        }
      }
    }
    return {
      courses: [],
      displayIndex: 0,
      appointment: {},
      value1: '',
      activeNames: '1',
      activeNames_p: '1',
      dynamicTags: ['Python', 'Java', 'Node.js'],
      inputVisible: false,
      inputValue: '',
      resume_loaded: false,
      resume_form: {
        name: '',
        phone: '',
        email: ''
      },
      rules: {
        name: [
          { required: true, message: 'Pleace enter your name', trigger: 'blur' }
        ],
        phone: [
          { required: true, message: 'Pleace enter your phone', trigger: 'blur' }
        ],
        email: [
          { required: true, message: 'Pleace enter your email', trigger: 'blur' },
          { type: 'email', message: 'Pleace enter right email address', trigger: ['blur', 'change'] }
        ],
        resume_type: [
          { required: true, message: 'Pleace choose your resume type', trigger: 'change' }
        ],
        education_date: [
          { validator: validateEducationDate, trigger: 'blur' }
        ]
      }
    }
  },
  computed: {
    displayCourse() {
      let coursedata = {}
      if (this.courses.length !== 0) {
        coursedata = this.courses[this.displayIndex]
      }
      return coursedata
    },
    pdfurl() {
      return '/api/v1/resume/getresumePDF?uid=' + this.$store.getters.id + '&r=' + Math.ceil(Math.random() * 10)
    }
  },
  created() {
    this.initData()
  },
  methods: {
    handleClose(tag) {
      this.dynamicTags.splice(this.dynamicTags.indexOf(tag), 1)
    },

    showInput() {
      this.inputVisible = true
      this.$nextTick(_ => {
        this.$refs.saveTagInput.$refs.input.focus()
      })
    },

    handleInputConfirm() {
      const inputValue = this.inputValue
      if (inputValue) {
        this.dynamicTags.push(inputValue)
      }
      this.inputVisible = false
      this.inputValue = ''
    },
    handleFilter() {
      getAppointmentBySidCid(this.$store.getters.id, this.courses[this.displayIndex].id).then(response => {
        this.appointment = response
      })
    },
    initData() {
      getInfo().then(response => {
        this.userinfo = response
        if (this.userinfo.uploadedresume === 0) {
          this.$notify({
            title: 'Resume',
            message: 'Please Upload your resume first, then you can edit your resume.',
            type: 'warning',
            duration: 3000
          })
          const view = this.$route
          this.$store.dispatch('delView', view).then(({ visitedViews }) => {
            this.$router.push('/')
          })
        } else {
          getResumeData().then(response => {
            this.resume_form = response
            console.log(response.resume_type)
            if ((typeof response.resume_type === 'string') && response.resume_type.constructor === String) {
              this.resume_form.resume_type = [response.resume_type]
            } else {
              this.resume_form.resume_type = response.resume_type
            }
            this.resume_loaded = true
          })
        }
      })
    },
    handleEdit() {
      this.$router.push({
        path: '/course/edit/',
        query: {
          title: 'Edit-Course-' + this.selectedcourse.id,
          action: 'Edit',
          id: this.selectedcourse.id
        }
      })
    },
    handleAppointmentCreate() {
      if (this.displayCourse.status > 3) {
        this.$message({
          type: 'warning',
          message: 'The Appointments Collection of this course is close!'
        })
      } else if (Object.keys(this.appointment).length === 0) {
        this.$router.push({
          path: '/course/appointment/',
          query: {
            title: 'Add-Appointment',
            action: 'create',
            course_id: this.courses[this.displayIndex].id
          }
        })
      } else {
        this.$router.push({
          path: '/course/appointment/',
          query: {
            title: 'Edit-Appointment-' + this.appointment.id,
            action: 'edit',
            appointment_id: this.appointment.id
          }
        })
      }
    },
    handleOpertionButtonClick(action) {
      this.$refs.form.validate((valid) => {
        if (valid) {
          this.$prompt('Plean enter your password', 'Alert', {
            confirmButtonText: 'Confirm',
            cancelButtonText: 'Cancel',
            inputPattern: /[A-Za-z0-9]{6,20}/,
            inputType: 'password',
            showClose: false,
            inputErrorMessage: 'Error Password Format',
            beforeClose: (action, instance, done) => {
              if (action === 'confirm') {
                instance.confirmButtonLoading = true
                instance.confirmButtonText = 'Updating...'
                const updateinfo = deepClone(this.resume_form)
                updateinfo.password = instance.inputValue
                uploadResumeData(updateinfo).then(response => {
                  if (response.error_code === 0) {
                    this.$message({
                      type: 'success',
                      message: response.msg
                    })
                    const { fullPath } = this.$route
                    this.$nextTick(() => {
                      this.$router.replace({
                        path: '/redirect' + fullPath
                      })
                    })
                    instance.confirmButtonLoading = false
                    done()
                  } else {
                    this.$message({
                      type: 'error',
                      message: response.msg
                    })
                    instance.confirmButtonLoading = false
                    done()
                  }
                }).catch(err => {
                  console.log(err)
                })
                  .catch(() => {
                    this.$message({
                      type: 'info',
                      message: 'Cancel Submission'
                    })
                  })
              } else {
                instance.confirmButtonLoading = false
                done()
              }
            }
          })
        } else {
          this.$message({
            type: 'warning',
            message: 'There are some errors in the form.Please check it before submission'
          })
        }
      })
    },
    handleSearchAppointment() {
      this.$router.push({
        path: '/course/appointments_tch/'
      })
    }
  }
}
</script>
<style lang="scss" scoped>
iframe{border: none;min-height:800px;width:100%;}
.page-container {
  padding: 10px;
  height: 100%;
  background: rgb(240, 242, 245);
}
.box-card /deep/ .el-card__header {
  background: rgb(108, 176, 243);
  color:rgb(255, 255, 255);
  border: 0px;
  border-radius: 0px;
  border-top-right-radius:5px;
  border-top-left-radius:5px;
}
.tabs-card /deep/ .el-card__body {
  padding-left: 0px;
  padding-top: 15px;
  border-radius: 0px;
  border-bottom-right-radius:5px;
  border-bottom-left-radius:5px;
  background-color: #ffffff;
}
.box-card /deep/ .el-card__body {
  border-radius: 0px;
  border-bottom-right-radius:5px;
  border-bottom-left-radius:5px;
  background-color: #ffffff;
}
.pdf-preview /deep/ .el-card__body {
  padding: 0px;
  border-radius: 0px;
  border-bottom-right-radius:5px;
  border-bottom-left-radius:5px;
  background-color: #ffffff;
}
.box-card {
  border: 0px;
  margin: 5px;
  background-color: transparent;
  .head-title {
    margin-top: 0px;
    .head-text {
      display: inline-block;
      vertical-align: middle;
      padding-left: 10px;
    }
    .action-wrapper {
      float: right;
      vertical-align: middle;
      .item-icon {
        font-size: 22px;
        cursor:pointer;
        }
    }
  }
  .card_body-container {
    transition: min-width .5s;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.4);
    padding: 0px;
  }
}
.el-divider{
  margin-top: 12px;
}
.info-item{
  padding: 5px 10px;
  padding-left: 40px;
  .label{
    font-weight: 300;
    padding-top: 5px;
  }
}
.el-tag + .el-tag {
    margin-left: 10px;
  }
  .button-new-tag {
    margin-left: 10px;
    height: 32px;
    line-height: 30px;
    padding-top: 0;
    padding-bottom: 0;
  }
  .input-new-tag {
    width: 90px;
    margin-left: 10px;
    vertical-align: bottom;
  }
</style>
