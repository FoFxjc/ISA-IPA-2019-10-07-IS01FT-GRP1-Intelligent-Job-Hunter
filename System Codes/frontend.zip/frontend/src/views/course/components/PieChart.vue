<template>
  <div ref="chart" :class="className" :style="{height:height,width:width}" style="margin-top:16px;margin-bottom:0px;"/>
</template>

<script>
import echarts from 'echarts'
require('echarts/theme/macarons') // echarts theme
import { debounce } from '@/utils'

export default {
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '300px'
    },
    chartdata: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      chart: null,
      piedata: []
    }
  },
  watch: {
    chartdata: {
      handler(val, old) {
        if (val.length !== 0) {
          const displaydata = []
          for (var i in val) {
            displaydata.push({ name: i, value: val[i] })
          }
          this.chart.setOption({
            series: [{
              data: displaydata
            }]
          }, false)
        }
      },
      deep: true
    }
  },
  mounted() {
    this.initChart()
    this.__resizeHandler = debounce(() => {
      if (this.chart) {
        this.chart.resize()
      }
    }, 100)
    window.addEventListener('resize', this.__resizeHandler)
    // 监听侧边栏的变化
    this.sidebarElm = document.getElementsByClassName('sidebar-container')[0]
    this.sidebarElm && this.sidebarElm.addEventListener('transitionend', this.sidebarResizeHandler)
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    window.removeEventListener('resize', this.__resizeHandler)
    this.sidebarElm && this.sidebarElm.removeEventListener('transitionend', this.sidebarResizeHandler)
    this.chart.dispose()
    this.chart = null
  },
  methods: {
    refresh() {
      if (this.chartdata.length !== 0) {
        const displaydata = []
        for (var i in this.chartdata) {
          displaydata.push({ name: i, value: this.chartdata[i] })
        }
        this.chart.setOption({
          series: [{
            data: displaydata
          }]
        }, false)
      }
    },
    sidebarResizeHandler(e) {
      if (e.propertyName === 'width') {
        this.__resizeHandler()
      }
    },
    initChart() {
      this.chart = echarts.init(this.$refs.chart, 'macarons')
      this.chart.setOption({
        tooltip: {
          trigger: 'item',
          formatter: '{a} <br/>{b}: {c} ({d}%)',
          enterable: true,
          position: function(pos, params, dom, rect, size) {
            // 鼠标在左侧时 tooltip 显示到右侧，鼠标在右侧时 tooltip 显示到左侧。
            var obj = { top: 230 }
            obj[['left', 'right'][+(pos[0] < size.viewSize[0] / 2)]] = 5
            return obj
          }
        },
        legend: {
          orient: 'vertical',
          x: 'left',
          data: ['Waiting', 'Approved', 'Close']
        },
        series: [
          {
            name: 'Appointments',
            type: 'pie',
            radius: ['50%', '65%'],
            avoidLabelOverlap: false,
            label: {
              normal: {
                show: false,
                position: 'center'
              },
              emphasis: {
                show: true,
                textStyle: {
                  fontSize: '15',
                  fontWeight: 'bold'
                }
              }
            },
            labelLine: {
              normal: {
                show: false
              }
            },
            data: this.chartdata
          }
        ]
      })
    }
  }
}
</script>
