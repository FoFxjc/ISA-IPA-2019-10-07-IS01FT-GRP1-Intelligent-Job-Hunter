<template>
  <div class="page-container">
    <el-card class="box-card tabs-card" shadow="always" style="min-height:200px;">
      <div slot="header" class="clearfix head-title">
        <div class="head-text" style="font-size:20px;margin-top:5px;">
          Job Position and Cover Letter
        </div>
        <div
          class="action-wrapper"
        >
          <el-tooltip class="item" effect="dark" content="Submit" placement="top-start">
            <operation-button action="doschedule" style="margin-left:5px;" @handleOpertionButtonClick="handleOpertionButtonClick"/>
          </el-tooltip>
        </div>
      </div>
      <div style="margin: 15px 30px;">
        <el-checkbox :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">All</el-checkbox>
        <div style="margin: 15px 0;"/>
        <el-checkbox-group v-model="job_select_list" @change="handleCheckedChange">
          <el-checkbox v-for="item in job_check_list" :label="item.key" :key="item.key">{{ item.value }}</el-checkbox>
        </el-checkbox-group>
      </div>
    </el-card>
    <el-tabs v-if="job_select_list.length !== 0 && coverletter_list[0]" v-model="activeName" type="border-card" tab-position="top" style="margin-top:10px;" @tab-click="handleClick">
      <el-tab-pane v-for="(item, index) in coverletter_list" :label="'Job '+item.index" :name="'Job '+item.index" :key="index" style="height:800px;">
        <split-pane :min-percent="40" :default-percent="50" split="vertical" @resize="resize">
          <template slot="paneL">
            <el-form :ref="'cv_form'+item.id" :model="item.data" :rules="rules" label-position="top" label-width="180px" style="margin: 5px 5px;">
              <el-tabs tab-position="right" style="padding:0px;">
                <el-tab-pane label="Sender Info" style="min-height:500px;">
                  <el-row>
                    <el-col :span="16">
                      <el-form-item label="Name" prop="sender_name">
                        <el-input v-model="item.data.sender_name" class="article-input" placeholder="Name"/>
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="16">
                      <el-form-item label="Phone" prop="sender_phone">
                        <el-input v-model="item.data.sender_phone" class="article-input" placeholder="Phone"/>
                      </el-form-item>
                    </el-col>
                  </el-row>
                  <el-row>
                    <el-col :span="16">
                      <el-form-item label="Email" prop="sender_email">
                        <el-input v-model="item.data.sender_email" class="article-input" placeholder="Email"/>
                      </el-form-item>
                    </el-col>
                  </el-row>

                </el-tab-pane>
                <el-tab-pane label="Recipiant Title" style="min-height:500px;">
                  <el-row>
                    <el-col :span="16">
                      <el-form-item label="Recipiant Title" prop="recipiant_title">
                        <el-input v-model="item.data.recipiant_title" class="article-input" placeholder="Name"/>
                      </el-form-item>
                    </el-col>
                  </el-row>
                </el-tab-pane>
                <el-tab-pane label="First Paragraph" style="min-height:500px;">
                  <el-form-item label="First Paragraph" prop="first_paragraph">
                    <el-input
                      :autosize="{ minRows: 6, maxRows: 10}"
                      v-model="item.data.first_paragraph"
                      type="textarea"
                      placeholder=""/>
                  </el-form-item>
                </el-tab-pane>
                <el-tab-pane label="Second Paragraph" style="min-height:500px;">
                  <el-form-item label="Second Paragraph" prop="secend_paragraph">
                    <el-input
                      :autosize="{ minRows: 6, maxRows: 10}"
                      v-model="item.data.secend_paragraph"
                      type="textarea"
                      placeholder=""/>
                  </el-form-item>
                </el-tab-pane>
                <el-tab-pane label="Third Paragraph" style="min-height:500px;">
                  <el-form-item label="Third Paragraph" prop="third_paragraph">
                    <el-input
                      :autosize="{ minRows: 6, maxRows: 10}"
                      v-model="item.data.third_paragraph"
                      type="textarea"
                      placeholder=""/>
                  </el-form-item>
                </el-tab-pane>
                <el-tab-pane label="Fourth Paragraph" style="min-height:500px;">
                  <el-form-item label="Fourth Paragraph" prop="fourth_paragraph">
                    <el-input
                      :autosize="{ minRows: 6, maxRows: 10}"
                      v-model="item.data.fourth_paragraph"
                      type="textarea"
                      placeholder=""/>
                  </el-form-item>
                </el-tab-pane>
                <el-tab-pane label="Regenerate" style="min-height:500px;">
                  <el-button :loading="reg_loading" type="primary" @click="handleReGenerate('cv_form'+item.id,item)">Regenerate</el-button>
                </el-tab-pane>
              </el-tabs>
            </el-form>
          </template>
          <template slot="paneR">
            <el-tabs tab-position="left" style="min-height: 200px;">
              <el-tab-pane label="Job Position">
                <iframe
                  :id="item.job+'jobpdf'"
                  :src="'/api/v1/coverletter/getJobPDF?job_id=' + item.job + '&r=' +getRandomNum"
                  frameborder="0"
                  marginwidth="0"
                  marginheight="0"
                  vspace="0"
                  hspace="0"
                  allowtransparency="true"
                  scrolling="no"/>
              </el-tab-pane>
              <el-tab-pane label="Cover Letter">
                <iframe
                  :id="item.id+'_cvdf'"
                  :src="'/api/v1/coverletter/getCoverLetterPDF?cv_id=' + item.id + '&r=' + getRandomNum"
                  frameborder="0"
                  marginwidth="0"
                  marginheight="0"
                  vspace="0"
                  hspace="0"
                  allowtransparency="true"
                  scrolling="no"/>
              </el-tab-pane>
            </el-tabs>

          </template>
        </split-pane>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>
<script>
import OperationButton from './components/OperationButton'
import BoxCard from './components/BoxCard'
import { getAppointmentBySidCid } from '@/api/appointment'
import { updateCoverLettersData } from '@/api/coverletter'
import splitPane from 'vue-splitpane'
import { getCoverLetters, submitDailyCoverLetter } from '@/api/coverletter'
import { validateEmail } from '@/utils/validate'
export default {
  name: 'DashboardAdmin',
  components: {
    BoxCard,
    OperationButton,
    splitPane
  },
  data() {
    const validateEmail_register = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('Please Enter your Email'))
      } else {
        if (!validateEmail(value)) {
          callback(new Error('Wrong Email Format'))
        } else {
          callback()
        }
      }
    }
    return {
      courses: [],
      displayIndex: 0,
      appointment: {},
      value1: '',
      activeName: '',
      activeNames_p: '1',
      inputVisible: false,
      inputValue: '',
      job_select_list: [],
      job_check_list: [],
      coverletter_list: [],
      isIndeterminate: true,
      checkAll: true,
      reg_loading: false,
      rules: {
        sender_name: [
          { required: true, message: 'Pleace enter your name', trigger: 'blur' }
        ],
        sender_phone: [
          { required: true, message: 'Pleace choose your phone', trigger: 'blur' }
        ],
        sender_email: [
          { required: true, validator: validateEmail_register, trigger: 'blur' }
        ],
        recipiant_title: [
          { required: true, message: 'Pleace select a color for your scheduler', trigger: 'blur' }
        ],
        first_paragraph: [
          { required: true, message: 'Pleace enter first paragraph of this cover letter', trigger: 'blur' }
        ],
        second_paragraph: [
          { required: true, message: 'Pleace enter first paragraph of this cover letter', trigger: 'blur' }
        ],
        third_paragraph: [
          { required: true, message: 'Pleace enter first paragraph of this cover letter', trigger: 'blur' }
        ],
        fourth_paragraph: [
          { required: true, message: 'Pleace enter first paragraph of this cover letter', trigger: 'blur' }
        ]
      }
    }
  },
  computed: {
    displayCourse() {
      let coursedata = {}
      if (this.courses.length !== 0) {
        coursedata = this.courses[this.displayIndex]
      }
      return coursedata
    },
    getRandomNum() {
      return Math.ceil(Math.random() * 100)
    }
  },
  created() {
    const uid = this.$route.query.uid
    this.getCVData(uid)
  },
  methods: {
    handleReGenerate(formname, cv_data) {
      this.$refs[formname][0].validate(valid => {
        if (valid) {
          const updateinfo = cv_data.data
          updateinfo.id = cv_data.id
          this.reg_loading = true
          updateCoverLettersData(updateinfo).then(response => {
            if (response.error_code === 0) {
              this.$notify({
                title: 'Success',
                message: 'Regenerate Cover Letter Successfully',
                type: 'success',
                duration: 1000
              })
              window.frames[cv_data.id + '_cvdf'].contentWindow.location.reload()
              this.reg_loading = false
            } else {
              this.$message({
                type: 'error',
                message: response.msg
              })
            }
          }).catch(err => {
            console.log(err)
          })
        } else {
          this.$message({
            type: 'error',
            message: 'Something Wrong. Please sure your complete all the inputs'
          })
        }
      })
    },
    showTabPane(control, pane) {
      let dom = ''
      this.$nextTick(() => {
        dom = document.getElementById(pane)
        if (control === 1) {
          dom.style.display = 'inline-block'
        } else {
          dom.style.display = 'none'
        }
      })
    },
    handleCheckAllChange(val) {
      const all_jobs = []
      for (const i of this.job_check_list) {
        all_jobs.push(i.key)
      }
      this.job_select_list = val ? all_jobs : []
      this.isIndeterminate = false
      if (val) {
        for (const tab of this.job_check_list) {
          this.showTabPane(1, 'tab-' + tab.value)
        }
      } else {
        for (const tab of this.job_check_list) {
          this.showTabPane(0, 'tab-' + tab.value)
        }
      }
    },
    handleCheckedChange(value) {
      const checkedCount = value.length
      this.checkAll = checkedCount === this.job_check_list.length
      this.isIndeterminate = checkedCount > 0 && checkedCount < this.job_check_list.length
      const _value = this.job_select_list.sort()
      for (const tab of this.job_check_list) {
        this.showTabPane(0, 'tab-' + tab.value)
      }
      for (const i of _value) {
        const _tmp = this.job_check_list.find(function(x) {
          return x.key === i
        })
        this.showTabPane(1, 'tab-' + _tmp.value)
      }
      const _tmp = this.job_check_list.find(function(x) {
        return x.key === _value[0]
      })
      this.activeName = _tmp.value
    },
    handleClick(e) {
      const tab_name = e.name
      this.$refs['preview_' + tab_name].refreshpdf()
    },
    handleClose(tag) {
      this.dynamicTags.splice(this.dynamicTags.indexOf(tag), 1)
    },

    showInput() {
      this.inputVisible = true
      this.$nextTick(_ => {
        this.$refs.saveTagInput.$refs.input.focus()
      })
    },

    handleInputConfirm() {
      const inputValue = this.inputValue
      if (inputValue) {
        this.dynamicTags.push(inputValue)
      }
      this.inputVisible = false
      this.inputValue = ''
    },
    handleFilter() {
      getAppointmentBySidCid(this.$store.getters.id, this.courses[this.displayIndex].id).then(response => {
        this.appointment = response
      })
    },
    getCVData(uid) {
      getCoverLetters({ 'uid': uid }).then(response => {
        if (response.jobs.length === 0) {
          this.$message({
            type: 'warning',
            message: 'You already submit all the coverletter today!'
          })
          this.closeCurrentView()
        }
        const job_check_list = []
        let _count = 0
        const coverletter_list = []
        response.jobs.forEach((item, index, array) => {
          console.log(Number(_count) + 1)
          this.job_select_list.push(item)
          job_check_list.push({ 'index': _count, 'key': item, 'value': 'Job ' + (Number(_count) + 1) })
          const _tmp = response.coverletters.find(function(x) {
            return x.job === item
          })
          _tmp.index = Number(_count) + 1
          coverletter_list.push(_tmp)
          _count++
        })
        this.activeName = job_check_list[0].value
        this.job_check_list = job_check_list
        this.coverletter_list = coverletter_list
        console.log(this.coverletter_list)
      })
    },
    handleEdit() {
      this.$router.push({
        path: '/course/edit/',
        query: {
          title: 'Edit-Course-' + this.selectedcourse.id,
          action: 'Edit',
          id: this.selectedcourse.id
        }
      })
    },
    handleAppointmentCreate() {
      if (this.displayCourse.status > 3) {
        this.$message({
          type: 'warning',
          message: 'The Appointments Collection of this course is close!'
        })
      } else if (Object.keys(this.appointment).length === 0) {
        this.$router.push({
          path: '/course/appointment/',
          query: {
            title: 'Add-Appointment',
            action: 'create',
            course_id: this.courses[this.displayIndex].id
          }
        })
      } else {
        this.$router.push({
          path: '/course/appointment/',
          query: {
            title: 'Edit-Appointment-' + this.appointment.id,
            action: 'edit',
            appointment_id: this.appointment.id
          }
        })
      }
    },
    handleOpertionButtonClick(action) {
      if (this.job_select_list.length === 0) {
        this.$message({
          type: 'warning',
          message: 'Please choose one job at least!'
        })
      } else {
        this.$prompt('Plean enter your password', 'Alert', {
          confirmButtonText: 'Confirm',
          cancelButtonText: 'Cancel',
          inputPattern: /[A-Za-z0-9]{6,20}/,
          inputType: 'password',
          showClose: false,
          inputErrorMessage: 'Error Password Format',
          beforeClose: (action, instance, done) => {
            if (action === 'confirm') {
              instance.confirmButtonLoading = true
              instance.confirmButtonText = 'Submitting...'
              const updateinfo = {}
              updateinfo.jobs = this.job_select_list
              updateinfo.password = instance.inputValue
              submitDailyCoverLetter(updateinfo).then(response => {
                if (response.error_code === 0) {
                  this.$message({
                    type: 'success',
                    message: 'Daily Cover Letter Check Successfully, Please Check your wechat!'
                  })
                  this.closeCurrentView()
                  instance.confirmButtonLoading = false
                  done()
                } else {
                  instance.confirmButtonLoading = false
                  done()
                }
              }).catch(err => {
                console.log(err)
              })
                .catch(() => {
                  this.$message({
                    type: 'info',
                    message: 'Cancel Submission'
                  })
                })
            } else {
              instance.confirmButtonLoading = false
              done()
            }
          }
        })
      }
    },
    closeCurrentView() {
      const view = this.$route
      this.$store.dispatch('delView', view).then(({ visitedViews }) => {
        this.$router.push('/')
      })
    },
    handleSearchAppointment() {
      this.$router.push({
        path: '/course/appointments_tch/'
      })
    }
  }
}
</script>
<style lang="scss" scoped>
iframe{border: none;min-height:800px;width:100%;}
.page-container {
  padding: 10px;
  height: 100%;
  background: rgb(240, 242, 245);
}
.box-card /deep/ .el-card__header {
  background: rgb(108, 176, 243);
  color:rgb(255, 255, 255);
  border: 0px;
  border-radius: 0px;
  border-top-right-radius:5px;
  border-top-left-radius:5px;
}
.tabs-card /deep/ .el-card__body {
  padding-left: 0px;
  padding-top: 15px;
  border-radius: 0px;
  border-bottom-right-radius:5px;
  border-bottom-left-radius:5px;
  background-color: #ffffff;
}
.box-card /deep/ .el-card__body {
  border-radius: 0px;
  border-bottom-right-radius:5px;
  border-bottom-left-radius:5px;
  background-color: #ffffff;
}
.box-card {
  border: 0px;
  background-color: transparent;
  .head-title {
    margin-top: 0px;
    .head-text {
      display: inline-block;
      vertical-align: middle;
      padding-left: 10px;
    }
    .action-wrapper {
      float: right;
      vertical-align: middle;
      .item-icon {
        font-size: 22px;
        cursor:pointer;
        }
    }
  }

  .card_body-container {
    transition: min-width .5s;
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.4);
    padding: 0px;
  }
}
.el-divider{
  margin-top: 12px;
}
.info-item{
  padding: 5px 10px;
  padding-left: 40px;
  .label{
    font-weight: 300;
    padding-top: 5px;
  }
}
.el-tag + .el-tag {
    margin-left: 10px;
  }
  .button-new-tag {
    margin-left: 10px;
    height: 32px;
    line-height: 30px;
    padding-top: 0;
    padding-bottom: 0;
  }
  .input-new-tag {
    width: 90px;
    margin-left: 10px;
    vertical-align: bottom;
  }
</style>
