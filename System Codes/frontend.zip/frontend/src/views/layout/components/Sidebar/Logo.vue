<template>
  <div class="menu-wrapper">
    <template>
      <div class="logo-con">
        <img v-show="collapsed" key="max-logo" :src="maxLogo" >
        <img v-show="!collapsed" key="min-logo" :src="minLogo" >
      </div>
    </template>
  </div>
</template>

<script>
import minLogo from '@/assets/logo-min.jpg'
import maxLogo from '@/assets/logo.jpg'
import Item from './Item'

export default {
  name: 'SidebarItem',
  components: { Item },
  data() {
    return {
      collapsed: this.$store.getters.sidebar.opened,
      minLogo,
      maxLogo
    }
  },
  methods: {
  }
}
</script>
<style lang="scss" scoped>
.logo-con{
    height: 64px;
    padding: 10px 2px;
    img {
      height: 44px;
      width: auto;
      display: block;
      margin: 0 auto;
    }
  }
</style>

