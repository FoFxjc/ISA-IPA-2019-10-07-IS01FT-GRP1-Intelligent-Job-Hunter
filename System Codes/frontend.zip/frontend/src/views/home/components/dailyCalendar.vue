<template>
  <component
    ref="tuiCal"
    :is="type"
    :use-detail-popup="useDetailPopup"
    :view="selectedView"
    :calendars="calendarList"
    :schedules="scheduleList"
    :theme="theme"
    :template="template"
    :task-view="taskView"
    :schedule-view="scheduleView"
    :timezones="timezones"
    :disable-dbl-click="disableDblClick"
    :is-read-only="isReadOnly"
    :use-creation-popup="useCreationPopup"
    style="height: 800px;z-index:99;"
  />
</template>
<script>
import 'tui-time-picker/dist/tui-time-picker.css'
import 'tui-date-picker/dist/tui-date-picker.css'
import 'tui-calendar/dist/tui-calendar.css'
import { deepClone } from '@/utils/index'
import { Calendar } from '@toast-ui/vue-calendar'
import { getCalendar } from '@/api/calendar'
export default {
  name: 'App',
  components: {
    'calendar': Calendar
  },
  props: {
    calendarinfo: {
      type: Object,
      default: () => {}
    }
  },
  data() {
    return {
      viewModeOptions: [
        {
          title: 'Monthly',
          value: 'month'
        },
        {
          title: 'Weekly',
          value: 'week'
        },
        {
          title: 'Daily',
          value: 'day'
        }
      ],
      dateRange: '',
      selectedView: 'day',
      calendarList: [
        {
          id: '0',
          name: 'Reading',
          bgColor: '#00a9ff',
          borderColor: '#00a9ff'
        },
        {
          id: '1',
          name: 'Writing',
          bgColor: '#00DB00',
          borderColor: '#00DB00'
        },
        {
          id: '2',
          name: 'Listening',
          bgColor: '#9e5fff',
          borderColor: '#9e5fff'
        },
        {
          id: '3',
          name: 'Speaking',
          bgColor: '#FF5809',
          borderColor: '#FF5809'
        }
      ],
      scheduleList: [
        {
          id: '1',
          calendarId: '0',
          title: 'Reading',
          category: 'time',
          dueDateClass: '',
          start: new Date(2019, 8, 19, 8).toLocaleString(),
          end: new Date(2019, 8, 19, 10).toLocaleString()
        },
        {
          id: '2',
          calendarId: '1',
          title: 'Writing',
          category: 'time',
          dueDateClass: '',
          start: new Date(2019, 8, 19, 13, 30).toLocaleString(),
          end: new Date(2019, 8, 19, 15, 30).toLocaleString(),
          isReadOnly: true
        }
      ],
      timezones: [{
        timezoneOffset: 480,
        displayLabel: 'GMT+08:00',
        tooltip: 'Seoul'
      }],
      taskView: false,
      scheduleView: ['time'],
      useDetailPopup: true,
      disableDblClick: true,
      useCreationPopup: false,
      isReadOnly: true,
      type: ''
    }
  },
  watch: {
    scheduleList(newValue) {
      let fullcalendar = true
      newValue.forEach(element => {
        if (element.isVisible === false) {
          fullcalendar = false
        }
      })
      this.$refs.fullcalendar.checked = fullcalendar
    }
  },
  mounted() {
    this.init()
  },
  methods: {
    init() {
      this.getPersonalCalendar()
    },
    getPersonalCalendar() {
      getCalendar().then(response => {
        this.calendarList = response.calendarList
        this.scheduleList = response.scheduleList
        this.type = 'calendar'
        this.setRenderRangeText()
      })
    },
    setRenderRangeText() {
      if (this.$refs.tuiCal) {
        const { invoke } = this.$refs.tuiCal
        const view = invoke('getViewName')
        const calDate = invoke('getDate')
        const rangeStart = invoke('getDateRangeStart')
        const rangeEnd = invoke('getDateRangeEnd')
        let year = calDate.getFullYear()
        let month = calDate.getMonth() + 1
        let date = calDate.getDate()
        let dateRangeText = ''
        let endMonth, endDate, start, end
        switch (view) {
          case 'month':
            dateRangeText = `${year}.${month}`
            break
          case 'week':
            year = rangeStart.getFullYear()
            month = rangeStart.getMonth() + 1
            date = rangeStart.getDate()
            endMonth = rangeEnd.getMonth() + 1
            endDate = rangeEnd.getDate()
            start = `${year}.${month}.${date} `
            end = `${endMonth}-${endDate}`
            dateRangeText = `${start}.${end}`
            break
          default:
            dateRangeText = `${year}.${month}.${date}`
        }
        this.dateRange = dateRangeText
      } else {
        setInterval(() => {
          this.setRenderRangeText()
        }, 200)
      }
    },
    onClickNavi(event) {
      this.$refs.tuiCal.invoke(event)
      this.setRenderRangeText()
    },
    findCalendar(calendarId) {
      return this.calendarList.find(item => item.id === calendarId)
    },
    onChangeNewScheduleCalendar(event) {
      const remain_scheduleList = deepClone(this.scheduleList)
      if (!event.target.checked) {
        this.$refs['calender_icon_' + event.target.value][0].style.backgroundColor = 'white'
        remain_scheduleList.forEach(element => {
          if (element.calendarId === event.target.value) {
            element.isVisible = false
          }
        })
      } else {
        this.$refs['calender_icon_' + event.target.value][0].style.backgroundColor = this.findCalendar(event.target.value).borderColor
        remain_scheduleList.forEach(element => {
          if (element.calendarId === event.target.value) {
            element.isVisible = true
          }
        })
      }
      this.scheduleList = remain_scheduleList
    },
    showfullcalendar() {
      const remain_scheduleList = deepClone(this.scheduleList)
      if (this.$refs.fullcalendar.checked) {
        remain_scheduleList.forEach(element => {
          element.isVisible = true
          this.$refs['calender_icon_' + element.calendarId][0].style.backgroundColor = this.findCalendar(element.calendarId).borderColor
        })
      } else {
        remain_scheduleList.forEach(element => {
          element.isVisible = false
          this.$refs['calender_icon_' + element.calendarId][0].style.backgroundColor = 'white'
        })
      }
      this.scheduleList = remain_scheduleList
    }
  }
}
</script>
<style>
.menu {
  top: 49px;
  bottom: 0;
  border-right: 1px solid #d5d5d5;
  padding: 12px 10px;
  text-align: center;
  background: #fafafa;
}
.menu .label {
  margin-bottom: 0;
  cursor: pointer;
}
.lnb-new-schedule {
  padding: 6px 0px;
  padding-top: -6px;
  border-bottom: 1px solid #e5e5e5;
}

.lnb-new-schedule-btn {
  height: 100%;
  font-size: 14px;
  background-color: #ff6618;
  color: #ffffff;
  border: 0;
  border-radius: 25px;
  padding: 10px 20px;
  font-weight: bold;
}

.lnb-new-schedule-btn:hover {
  height: 100%;
  font-size: 14px;
  background-color: #e55b15;
  color: #ffffff;
  border: 0;
  border-radius: 25px;
  padding: 10px 20px;
  font-weight: bold;
}

.lnb-new-schedule-btn:active {
  height: 100%;
  font-size: 14px;
  background-color: #d95614;
  color: #ffffff;
  border: 0;
  border-radius: 25px;
  padding: 10px 20px;
  font-weight: bold;
}

.toolbar{
  padding-bottom: 5px;
}

.lnb-calendars > div {
  padding: 12px 6px;
  border-bottom: 1px solid #e5e5e5;
  font-weight: normal;
}

.lnb-calendars-d1 {
  padding-left: 8px;
}

.lnb-calendars-d1 label {
  font-weight: normal;
}

.lnb-calendars-item {
  min-height: 13px;
  line-height: 13px;
  padding: 8px 0;
  font-size: 14px;
  text-align: left;
}

.calendar{
  padding: 5px 6px;
}
.el-select .el-input__inner {

  width: 100px;

}
</style>
