import request from '@/utils/request'

export function login(data) {
  return request({
    url: '/api/v1/token',
    method: 'post', // method post in the pro
    data
  })
}

export function getLoginQR() {
  return request({
    url: '/api/v1/wechat/wechatQR',
    method: 'get'
  })
}

export function getInfo(token) {
  return request({
    url: '/api/v1/user/info',
    method: 'get'
  })
}

export function logout() {
  return request({
    url: '/user/logout',
    method: 'get' // method post in the pro
  })
}

export function getUsers(form) {
  return request({
    url: '/api/v1/user/list',
    method: 'post', // method post in the pro
    data: JSON.stringify(form)
  })
}
export function updateUserInfo(data) {
  return request({
    url: '/api/v1/user/update',
    method: 'post', // method post in the pro
    data
  })
}
export function updatePassword(data) {
  return request({
    url: '/api/v1/user/updatepassword',
    method: 'post', // method post in the pro
    data
  })
}

export function uploadMonitorEmail(data) {
  return request({
    url: '/api/v1/user/uploadmonitorEmail',
    method: 'post', // method post in the pro
    data
  })
}
export function register(data) {
  return request({
    url: '/api/v1/user/register',
    method: 'post', // method post in the pro
    data
  })
}
