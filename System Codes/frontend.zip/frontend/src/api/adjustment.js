import request from '@/utils/request'

export function getAdjustments() {
  return request({
    url: '/v1/adjustment/list',
    method: 'get'
  })
}
