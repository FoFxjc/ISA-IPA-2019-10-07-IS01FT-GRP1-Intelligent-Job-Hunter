import request from '@/utils/request'

export function getApps() {
  return request({
    url: 'v1/home/apps',
    method: 'get'
  })
}
