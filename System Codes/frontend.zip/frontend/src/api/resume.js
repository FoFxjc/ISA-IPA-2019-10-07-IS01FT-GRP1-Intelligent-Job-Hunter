import request from '@/utils/request'

export function getResumeData() {
  return request({
    url: '/api/v1/resume/getresumeData',
    method: 'get'
  })
}

export function uploadResumeData(data) {
  return request({
    url: '/api/v1/resume/uploadresumeData',
    method: 'post',
    data
  })
}

