import request from '@/utils/request'

export function getCoverLetters(data) {
  return request({
    url: '/api/v1/coverletter/getCoverLetterData',
    method: 'post',
    data
  })
}

export function updateCoverLettersData(data) {
  return request({
    url: '/api/v1/coverletter/uploadCoverLetterData',
    method: 'post',
    data
  })
}

export function submitDailyCoverLetter(data) {
  return request({
    url: '/api/v1/coverletter/submit',
    method: 'post',
    data
  })
}

// export function uploadResumeData(data) {
//   return request({
//     url: '/api/v1/resume/uploadresumeData',
//     method: 'post',
//     data
//   })
// }

