import request from '@/utils/request'

export function getlogList(log_type, log_id) {
  return request({
    url: '/v1/log?log_type=' + log_type + '&log_id=' + log_id,
    method: 'get' // method post in the pro
  })
}
