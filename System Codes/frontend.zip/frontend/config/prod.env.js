'use strict'

module.exports = {
  NODE_ENV: '"production"',
  BASE_API: '"http://159.138.99.244:5000"'
}
