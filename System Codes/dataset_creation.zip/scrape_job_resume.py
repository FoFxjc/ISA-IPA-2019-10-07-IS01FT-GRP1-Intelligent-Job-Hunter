#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Oct 29 15:34:13 2019

@author: nirmalenduprakash
"""

import tagui as t
import os
import re

class util:
    def __init__(self):
        self.output=[]
    def removeNesting(self,l):
        for i in l: 
            if type(i) == list: 
                self.removeNesting(i) 
            else: 
                self.output.append(i)
        return self.output 
    
try:
    t.close()
    t.init()
except:
    pass

job_types=[]
with open('job_type.json','r') as f:
    job_types.append(f.read().split('\n'))

job_types=util().removeNesting(job_types)
job_types=[typ for typ in job_types if typ!='']

UX=['UX']
Manager=['IT Manager']
SoftwareEngineer=['big data engineer','full stack developer','software engineer','front end developer']
AI=['Data Scientist','AI']

urls=[]
selector=f'//a[@class="jobtitle turnstileLink "]'
for job in job_types:
    url='https://www.indeed.com.sg/jobs?q='+job
    t.url(url)
    t.wait(2)
    counter=0
    while(counter<5):
        count=t.count(selector)
        for i in range(1,count+1):        
            if(job in SoftwareEngineer):
                urls.append('software engineer-https://www.indeed.com.sg'+t.read(f'(//a[@class="jobtitle turnstileLink "])[{i}]/@href'))
            elif(job in AI):
                urls.append('AI-https://www.indeed.com.sg'+t.read(f'(//a[@class="jobtitle turnstileLink "])[{i}]/@href'))
            elif(job in UX):
                urls.append('UX-https://www.indeed.com.sg'+t.read(f'(//a[@class="jobtitle turnstileLink "])[{i}]/@href'))
            elif(job in Manager):    
                urls.append('Manager-https://www.indeed.com.sg'+t.read(f'(//a[@class="jobtitle turnstileLink "])[{i}]/@href'))
        counter+=1
        t.click('//span[@class="np" and contains(text(),"Next")]')
        t.wait(2)
        
with open('job_urls.txt','w') as f:
    for item in urls:
        f.write("%s\n" % item)

counter=0
for typ in ['AI','Manager','UX']:
    baseDir=os.getcwd()+os.sep+typ
    with open('job_urls.txt','r') as f:
        for line in f:
            if(typ+'-' in line and counter>256):
                url=line.replace(typ+'-','')
                print(url)
                t.url(url)
                t.wait(2)
                data=[]
                for i in range(1,5):
                    try:
                        data.append((t.read(f'(//div[@id="jobDescriptionText"]//ul[li])[{i}]//preceding-sibling::p[1]'),
                                     t.read(f'(//div[@id="jobDescriptionText"]//ul[li])[{i}]')))
                    except:
                        pass    
                for k,v in data:
                    if(k!=''):
                        if(not os.path.isdir(baseDir+str(counter))):
                            os.makedirs(baseDir+str(counter))                        
                        with open(baseDir+str(counter)+'/'+ re.sub('[^A-Za-z0-9 ]+', '',k[:50])+'.txt','a+') as w:
                            w.write(v) 
            counter+=1         
        